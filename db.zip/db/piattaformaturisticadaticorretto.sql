USE piattaformaturistica;

-----------------------------------------------------
-- Agenzie (3)
-----------------------------------------------------
INSERT INTO Agenzia (nome, sede) VALUES
('AgenziaViaggiRoma', 'Via Roma 10, Roma'),
('TravelWorld', 'Via Milano 22, Milano'),
('HappyTour', 'Via Firenze 15, Firenze');


-----------------------------------------------------
-- 10 Città
-----------------------------------------------------
INSERT INTO Citta (nome, regione, nazione) VALUES
('Roma', 'Lazio', 'Italia'),
('Milano', 'Lombardia', 'Italia'),
('Venezia', 'Veneto', 'Italia'),
('Firenze', 'Toscana', 'Italia'),
('Napoli', 'Campania', 'Italia'),
('Torino', 'Piemonte', 'Italia'),
('Bologna', 'Emilia-Romagna', 'Italia'),
('Genova', 'Liguria', 'Italia'),
('Palermo', 'Sicilia', 'Italia'),
('Verona', 'Veneto', 'Italia');

-----------------------------------------------------
-- 10 Lingue
-----------------------------------------------------
INSERT INTO Lingua (nome) VALUES
('Italiano'),
('Inglese'),
('Spagnolo'),
('Francese'),
('Tedesco'),
('Portoghese'),
('Cinese'),
('Giapponese'),
('Arabo'),
('Russo');

INSERT INTO Servizio (nome, tipo) VALUES
('Wi-Fi','base'),
('Colazione','comfort'),
('Pulizia giornaliera','pulizia'),
('Cucina attrezzata','cucina'),
('Accesso disabili','accessibilità'),
('Adatto a famiglie','famiglia'),
('Animali ammessi','animali'),
('Sala riunioni','business'),
('Spa','benessere'),
('Parcheggio','mobilità'),
('Riscaldamento','comfort'),
('Aria condizionata','comfort'),
('Tv in camera','base'),
('Piscina','benessere'),
('Servizio navetta','mobilità'),
('Balcone','comfort'),
('Lavatrice','comfort'),
('Asciugatrice','comfort'),
('Kit benvenuto','base'),
('Servizio lavanderia','comfort'),
('Colazione vegana','cucina'),
('Kit primo soccorso','base'),
('Deposito bagagli','base'),
('Mini bar','comfort'),
('Camere insonorizzate','comfort'),
('Cassetta di sicurezza','base'),
('Sauna','benessere'),
('Area giochi bambini','famiglia'),
('Servizio baby-sitter','famiglia'),
('Ginnastica/fitness','benessere');

-----------------------------------------------------
-- 6 Badge
-----------------------------------------------------
INSERT INTO Badge (ID) VALUES
(NULL),
(NULL),
(NULL),
(NULL),
(NULL),
(NULL);

-- 30 Host
-----------------------------------------------------
-- 24 Host privati (tra cui 6 superhost)
INSERT INTO Host (email, data_nomina, tasso_risposta, nazionalita, tipo_host, Agenzia_nome) VALUES
('host01@email.it','2023-01-01',95.00,'Italiana','host privato',NULL),
('host02@email.it','2023-01-05',90.00,'Italiana','host privato',NULL),
('host03@email.it','2023-02-01',85.00,'Italiana','host privato',NULL),
('host04@email.it','2023-02-10',92.00,'Italiana','host privato',NULL),
('host05@email.it','2023-03-01',88.00,'Italiana','host privato',NULL),
('host06@email.it','2023-03-05',90.00,'Italiana','host privato',NULL),
('host07@email.it','2023-04-01',91.00,'Italiana','host privato',NULL),
('host08@email.it','2023-04-10',93.00,'Italiana','host privato',NULL),
('host09@email.it','2023-05-01',87.00,'Italiana','host privato',NULL),
('host10@email.it','2023-05-05',89.00,'Italiana','host privato',NULL),
('host11@email.it','2023-06-01',90.00,'Italiana','host privato',NULL),
('host12@email.it','2023-06-10',92.00,'Italiana','host privato',NULL),
('host13@email.it','2023-07-01',85.00,'Italiana','host privato',NULL),
('host14@email.it','2023-07-05',88.00,'Italiana','host privato',NULL),
('host15@email.it','2023-08-01',90.00,'Italiana','host privato',NULL),
('host16@email.it','2023-08-10',87.00,'Italiana','host privato',NULL),
('host17@email.it','2023-09-01',92.00,'Italiana','host privato',NULL),
('host18@email.it','2023-09-05',90.00,'Italiana','host privato',NULL),
('host19@email.it','2023-10-01',88.00,'Italiana','superhost',NULL),
('host20@email.it','2023-10-05',89.00,'Italiana','superhost',NULL),
('host21@email.it','2023-11-01',91.00,'Italiana','superhost',NULL),
('host22@email.it','2023-11-05',93.00,'Italiana','superhost',NULL),
('host23@email.it','2023-12-01',95.00,'Italiana','superhost',NULL),
('host24@email.it','2023-12-05',94.00,'Italiana','superhost',NULL);

-- 6 Host professionisti
INSERT INTO Host (email, data_nomina, tasso_risposta, nazionalita, tipo_host, Agenzia_nome) VALUES
('host25@email.it','2023-01-01',96.00,'Italiana','host professionista','AgenziaViaggiRoma'),
('host26@email.it','2023-02-01',97.00,'Italiana','host professionista','AgenziaViaggiRoma'),
('host27@email.it','2023-03-01',95.00,'Italiana','host professionista','TravelWorld'),
('host28@email.it','2023-04-01',94.00,'Italiana','host professionista','TravelWorld'),
('host29@email.it','2023-05-01',96.00,'Italiana','host professionista','HappyTour'),
('host30@email.it','2023-06-01',97.00,'Italiana','host professionista','HappyTour');

-----------------------------------------------------
-- 50 Utenti
-----------------------------------------------------
INSERT INTO Utente (email, nome, cognome, nazionalita, biografia) VALUES
('utente01@email.it','Luca','Rossi','Italiana','Appassionato di viaggi e cultura.'),
('utente02@email.it','Maria','Bianchi','Italiana','Ama il cibo locale e le escursioni.'),
('utente03@email.it','Giulia','Verdi','Italiana','Fotografa e amante dell’arte.'),
('utente04@email.it','Marco','Neri','Italiana','Appassionato di sport e natura.'),
('utente05@email.it','Francesca','Russo','Italiana','Ama le città storiche e la musica.'),
('utente06@email.it','Andrea','Ferrari','Italiana','Viaggiatore esperto.'),
('utente07@email.it','Sara','Esposito','Italiana','Curiosa e amante della cultura locale.'),
('utente08@email.it','Davide','Romano','Italiana','Ama la cucina e i mercati tipici.'),
('utente09@email.it','Elena','Colombo','Italiana',NULL),
('utente10@email.it','Matteo','Fontana','Italiana','Ama le escursioni e i viaggi in gruppo.'),
('utente11@email.it','Chiara','Moretti','Italiana','Viaggiatrice curiosa e creativa.'),
('utente12@email.it','Alessandro','Ricci','Italiana','Ama scoprire luoghi nascosti.'),
('utente13@email.it','Valentina','Mariani','Italiana','Appassionata di cultura e tradizioni.'),
('utente14@email.it','Simone','Galli','Italiana','Ama i tour storici e culturali.'),
('utente15@email.it','Federica','Grassi','Italiana','Curiosa di arte e gastronomia.'),
('utente16@email.it','Lorenzo','Rinaldi','Italiana',NULL),
('utente17@email.it','Martina','Costa','Italiana','Viaggiatrice appassionata di città d’arte.'),
('utente18@email.it','Gabriele','Sarti','Italiana','Ama la fotografia e la storia locale.'),
('utente19@email.it','Alice','Villa','Italiana','Curiosa e amante dei viaggi culturali.'),
('utente20@email.it','Riccardo','Lombardi','Italiana','Ama le esperienze culinarie.'),
('utente21@email.it','Elisa','Bianco','Italiana','Appassionata di arte e musica.'),
('utente22@email.it','Filippo','Conti','Italiana','Ama scoprire città storiche.'),
('utente23@email.it','Ilaria','Ferraro','Italiana','Viaggiatrice curiosa.'),
('utente24@email.it','Giorgio','Marchetti','Italiana','Appassionato di escursioni e natura.'),
('utente25@email.it','Valeria','Pellegrini','Italiana','Ama tour culturali e gastronomici.'),
('utente26@email.it','Nicola','Barbieri','Italiana','Viaggiatore esperto e curioso.'),
('utente27@email.it','Martina','Bellini','Italiana','Curiosa e amante dell’arte.'),
('utente28@email.it','Stefano','Giordano','Italiana','Ama i tour storici.'),
('utente29@email.it','Claudia','Fabbri','Italiana','Appassionata di cucina e tradizioni.'),
('utente30@email.it','Emanuele','Pini','Italiana','Ama viaggi in città d’arte.'),
('utente31@email.it','Alice','Griffi','Italiana','Curiosa e creativa.'),
('utente32@email.it','Daniele','Riva','Italiana','Ama la cultura e la storia locale.'),
('utente33@email.it','Francesca','Bertoli','Italiana','Viaggiatrice appassionata di arte.'),
('utente34@email.it','Luca','D’Angelo','Italiana','Ama scoprire città e tradizioni.'),
('utente35@email.it','Chiara','Capri','Italiana','Appassionata di cultura locale.'),
('utente36@email.it','Marco','Parisi','Italiana','Ama escursioni e natura.'),
('utente37@email.it','Giulia','Testa','Italiana','Curiosa e amante dell’arte.'),
('utente38@email.it','Matteo','Fabbiani','Italiana','Viaggiatore esperto.'),
('utente39@email.it','Sara','Vitale','Italiana','Ama gastronomia e cultura.'),
('utente40@email.it','Andrea','Sanna','Italiana','Curioso e appassionato di città d’arte.'),
('utente41@email.it','Elena','Gatti','Italiana','Appassionata di fotografia.'),
('utente42@email.it','Alessandro','Serra','Italiana','Ama tour culturali e naturali.'),
('utente43@email.it','Valentina','Bellini','Italiana','Viaggiatrice curiosa.'),
('utente44@email.it','Simone','Parisi','Italiana','Ama la storia locale.'),
('utente45@email.it','Federica','Bruni','Italiana','Curiosa e amante dell’arte.'),
('utente46@email.it','Lorenzo','Morelli','Italiana','Ama escursioni e trekking.'),
('utente47@email.it','Martina','Conti','Italiana','Viaggiatrice appassionata di cultura.'),
('utente48@email.it','Gabriele','Rossi','Italiana','Ama esperienze gastronomiche.'),
('utente49@email.it','Alice','Galli','Italiana','Curiosa e creativa.'),
('utente50@email.it','Riccardo','Romano','Italiana','Viaggiatore appassionato di arte e cultura.');

-- Alloggi
-- Camere singole (18)
INSERT INTO Alloggio (nome, tipo, indirizzo, piani, locali, mq, max_ospiti, descrizione, ammissione_animali, bagno_privato, giardino, genere, link_foto, Host_email, Citta_nome, costo_per_notte) VALUES
('Alloggio01','camera singola','Via Roma 1',NULL,NULL,20,1,'Camera singola confortevole',TRUE,FALSE,NULL,'lusso','foto01.jpg','host01@email.it','Roma',70),
('Alloggio02','camera singola','Via Milano 2',NULL,NULL,22,1,'Camera centrale',TRUE,TRUE,NULL,'buisness','foto02.jpg','host02@email.it','Milano',75),
('Alloggio03','camera singola','Via Venezia 3',NULL,NULL,18,1,'Piccola camera accogliente',TRUE,FALSE,NULL,'business','foto03.jpg','host03@email.it','Venezia',60),
('Alloggio04','camera singola','Via Firenze 4',NULL,NULL,20,1,'Camera luminosa',TRUE,TRUE,NULL,'bambino','foto04.jpg','host04@email.it','Firenze',65),
('Alloggio05','camera singola','Via Napoli 5',NULL,NULL,21,1,'Camera elegante',TRUE,FALSE,NULL,'lusso','foto05.jpg','host05@email.it','Napoli',80),
('Alloggio06','camera singola','Via Torino 6',NULL,NULL,19,1,'Camera moderna',FALSE,FALSE,NULL,'adulto','foto06.jpg','host06@email.it','Torino',55),
('Alloggio07','camera singola','Via Bologna 7',NULL,NULL,20,1,'Camera confortevole',TRUE,FALSE,NULL,'bambino','foto07.jpg','host07@email.it','Bologna',70),
('Alloggio08','camera singola','Via Genova 8',NULL,NULL,22,1,'Camera spaziosa',TRUE,FALSE,NULL,'generico','foto08.jpg','host08@email.it','Genova',75),
('Alloggio09','camera singola','Via Palermo 9',NULL,NULL,21,1,'Camera centrale',TRUE,FALSE,NULL,'generico','foto09.jpg','host09@email.it','Palermo',65),
('Alloggio10','camera singola','Via Verona 10',NULL,NULL,20,1,'Camera luminosa',TRUE,FALSE,NULL,'generico','foto10.jpg','host10@email.it','Verona',70),
('Alloggio11','camera singola','Via Roma 11',NULL,NULL,20,1,'Camera accogliente',TRUE,TRUE,NULL,'generico','foto11.jpg','host11@email.it','Roma',68),
('Alloggio12','camera singola','Via Milano 12',NULL,NULL,22,1,'Camera centrale',TRUE,FALSE,NULL,'generico','foto12.jpg','host12@email.it','Milano',72),
('Alloggio13','camera singola','Via Venezia 13',NULL,NULL,18,1,'Piccola camera accogliente',TRUE,FALSE,NULL,'generico','foto13.jpg','host13@email.it','Venezia',60),
('Alloggio14','camera singola','Via Firenze 14',NULL,NULL,20,1,'Camera luminosa',TRUE,FALSE,NULL,'generico','foto14.jpg','host14@email.it','Firenze',65),
('Alloggio15','camera singola','Via Napoli 15',NULL,NULL,21,1,'Camera elegante',TRUE,FALSE,NULL,'generico','foto15.jpg','host15@email.it','Napoli',78),
('Alloggio16','camera singola','Via Torino 16',NULL,NULL,19,1,'Camera moderna',TRUE,FALSE,NULL,'generico','foto16.jpg','host16@email.it','Torino',55),
('Alloggio17','camera singola','Via Bologna 17',NULL,NULL,20,1,'Camera confortevole',TRUE,FALSE,NULL,'generico','foto17.jpg','host17@email.it','Bologna',70),
('Alloggio18','camera singola','Via Genova 18',NULL,NULL,22,1,'Camera spaziosa',TRUE,FALSE,NULL,'generico','foto18.jpg','host18@email.it','Genova',75);

-- Appartamenti (36)
INSERT INTO Alloggio (nome, tipo, indirizzo, piani, locali, mq, max_ospiti, descrizione, ammissione_animali, bagno_privato, giardino, genere, link_foto, Host_email, Citta_nome, costo_per_notte) VALUES
('Alloggio19','appartamento','Via Roma 19',NULL,4,80,4,'Appartamento spazioso',TRUE,NULL,NULL,NULL,'foto19.jpg','host19@email.it','Roma',120),
('Alloggio20','appartamento','Via Milano 20',NULL,5,85,5,'Appartamento moderno',TRUE,NULL,NULL,NULL,'foto20.jpg','host20@email.it','Milano',130),
('Alloggio21','appartamento','Via Venezia 21',NULL,4,78,4,'Appartamento accogliente',TRUE,NULL,NULL,NULL,'foto21.jpg','host21@email.it','Venezia',110),
('Alloggio22','appartamento','Via Firenze 22',NULL,5,90,5,'Appartamento elegante',TRUE,NULL,NULL,NULL,'foto22.jpg','host22@email.it','Firenze',140),
('Alloggio23','appartamento','Via Napoli 23',NULL,4,82,4,'Appartamento luminoso',TRUE,NULL,NULL,NULL,'foto23.jpg','host23@email.it','Napoli',125),
('Alloggio24','appartamento','Via Torino 24',NULL,5,88,5,'Appartamento confortevole',TRUE,NULL,NULL,NULL,'foto24.jpg','host24@email.it','Torino',135),
('Alloggio25','appartamento','Via Palermo 25',NULL,4,79,4,'Appartamento ristrutturato',TRUE,NULL,NULL,NULL,'foto25.jpg','host25@email.it','Palermo',115),
('Alloggio26','appartamento','Via Bari 26',NULL,5,92,5,'Appartamento moderno e luminoso',TRUE,NULL,NULL,NULL,'foto26.jpg','host26@email.it','Bari',128),
('Alloggio27','appartamento','Via Genova 27',NULL,4,81,4,'Appartamento vicino al centro',TRUE,NULL,NULL,NULL,'foto27.jpg','host27@email.it','Genova',118),
('Alloggio28','appartamento','Via Perugia 28',NULL,5,87,5,'Appartamento elegante e spazioso',TRUE,NULL,NULL,NULL,'foto28.jpg','host28@email.it','Perugia',132),
('Alloggio29','appartamento','Via Cagliari 29',NULL,4,76,4,'Appartamento accogliente e silenzioso',TRUE,NULL,NULL,NULL,'foto29.jpg','host29@email.it','Cagliari',112),
('Alloggio30','appartamento','Via Trento 30',NULL,5,95,5,'Appartamento di design',TRUE,NULL,NULL,NULL,'foto30.jpg','host30@email.it','Trento',145),
('Alloggio31','appartamento','Via Bolzano 31',NULL,4,83,4,'Appartamento panoramico',TRUE,NULL,NULL,NULL,'foto31.jpg','host1@email.it','Bolzano',138),
('Alloggio32','appartamento','Via Padova 32',NULL,5,89,5,'Appartamento moderno e funzionale',TRUE,NULL,NULL,NULL,'foto32.jpg','host2@email.it','Padova',129),
('Alloggio33','appartamento','Via Lecce 33',NULL,4,77,4,'Appartamento vicino al mare',TRUE,NULL,NULL,NULL,'foto33.jpg','host3@email.it','Lecce',120),
('Alloggio34','appartamento','Via Verona 34',NULL,5,91,5,'Appartamento elegante e luminoso',TRUE,NULL,NULL,NULL,'foto34.jpg','host4@email.it','Verona',142),
('Alloggio35','appartamento','Via Pisa 35',NULL,4,80,4,'Appartamento tranquillo e moderno',TRUE,NULL,NULL,NULL,'foto35.jpg','host5@email.it','Pisa',118),
('Alloggio36','appartamento','Via Siena 36',NULL,5,93,5,'Appartamento raffinato e spazioso',TRUE,NULL,NULL,NULL,'foto36.jpg','host6@email.it','Siena',148);
-- Ville (6)
INSERT INTO Alloggio (nome, tipo, indirizzo, piani, locali, mq, max_ospiti, descrizione, ammissione_animali, bagno_privato, giardino, genere, link_foto, Host_email, Citta_nome, costo_per_notte) VALUES
('Alloggio55','villa','Via Lago 1',2,NULL,200,8,'Villa con giardino',TRUE,NULL,TRUE,NULL,'foto55.jpg','host25@email.it','Roma',300),
('Alloggio56','villa','Via Lago 2',2,NULL,210,8,'Villa panoramica',TRUE,NULL,TRUE,NULL,'foto56.jpg','host26@email.it','Milano',320),
('Alloggio57','villa','Via Lago 3',2,NULL,220,8,'Villa moderna con piscina',TRUE,NULL,TRUE,NULL,'foto57.jpg','host27@email.it','Venezia',350),
('Alloggio58','villa','Via Lago 4',2,NULL,230,8,'Villa elegante',TRUE,NULL,TRUE,NULL,'foto58.jpg','host28@email.it','Firenze',370),
('Alloggio59','villa','Via Lago 5',2,NULL,240,8,'Villa spaziosa',TRUE,NULL,TRUE,NULL,'foto59.jpg','host29@email.it','Napoli',400),
('Alloggio60','villa','Via Lago 6',2,NULL,250,8,'Villa lussuosa',TRUE,NULL,TRUE,NULL,'foto60.jpg','host30@email.it','Torino',450);



-----------------------------------------------------
-- 21 Esperienze
-----------------------------------------------------
INSERT INTO Esperienza (nome, data, max_partecipanti, descrizione, prezzo_unitario, Agenzia_nome) VALUES
('Esperienza01', '2025-12-05', 10, 'Tour guidato del centro storico', 50.00, 'AgenziaViaggiRoma'),
('Esperienza02', '2025-12-06', 15, 'Degustazione vini locali', 60.00, 'TravelWorld'),
('Esperienza03', '2025-12-07', 8, 'Lezione di cucina tradizionale', 70.00, 'HappyTour'),
('Esperienza04', '2025-12-08', 12, 'Escursione in montagna', 80.00, 'AgenziaViaggiRoma'),
('Esperienza05', '2025-12-09', 10, 'Tour artistico dei musei', 55.00, 'TravelWorld'),
('Esperienza06', '2025-12-10', 20, 'Passeggiata ecologica in natura', 45.00, 'HappyTour'),
('Esperienza07', '2025-12-11', 15, 'Corso di fotografia urbana', 65.00, 'AgenziaViaggiRoma'),
('Esperienza08', '2025-12-12', 8, 'Lezione di pittura su ceramica', 50.00, 'TravelWorld'),
('Esperienza09', '2025-12-13', 10, 'Tour notturno della città', 55.00, 'HappyTour'),
('Esperienza10', '2025-12-14', 12, 'Visita guidata al parco naturale', 60.00, 'AgenziaViaggiRoma'),
('Esperienza11', '2025-12-15', 15, 'Lezione di danza tradizionale', 70.00, 'TravelWorld'),
('Esperienza12', '2025-12-16', 10, 'Degustazione di cioccolato artigianale', 50.00, 'HappyTour'),
('Esperienza13', '2025-12-17', 20, 'Escursione in bicicletta', 45.00, 'AgenziaViaggiRoma'),
('Esperienza14', '2025-12-18', 12, 'Tour gastronomico dei quartieri storici', 65.00, 'TravelWorld'),
('Esperienza15', '2025-12-19', 8, 'Corso di yoga nel parco', 55.00, 'HappyTour'),
('Esperienza16', '2025-12-20', 10, 'Laboratorio di ceramica e scultura', 70.00, 'AgenziaViaggiRoma'),
('Esperienza17', '2025-12-21', 15, 'Visita guidata alle gallerie d’arte', 60.00, 'TravelWorld'),
('Esperienza18', '2025-12-22', 12, 'Tour storico dei monumenti principali', 50.00, 'HappyTour'),
('Esperienza19', '2025-12-23', 10, 'Escursione in barca sul fiume', 80.00, 'AgenziaViaggiRoma'),
('Esperienza20', '2025-12-24', 15, 'Laboratorio di cucina tipica', 65.00, 'TravelWorld'),
('Esperienza21', '2025-12-25', 20, 'Passeggiata culturale e fotografica', 55.00, 'HappyTour');


-----------------------------------------------------
-- Attrazioni (2 per città)
-----------------------------------------------------

INSERT INTO Attrazione (nome, Citta_nome) VALUES 
('Colosseo', 'Roma'),
('Piazza Navona', 'Roma'),

('Duomo di Milano', 'Milano'),
('Galleria Vittorio Emanuele II', 'Milano'),

('Piazza San Marco', 'Venezia'),
('Basilica di San Marco', 'Venezia'),

('Duomo di Firenze', 'Firenze'),
('Ponte Vecchio', 'Firenze'),

('Pompei', 'Napoli'),
('Castel dell’Ovo', 'Napoli'),

('Mole Antonelliana', 'Torino'),
('Parco del Valentino', 'Torino'),

('Torre degli Asinelli', 'Bologna'),
('Piazza Maggiore', 'Bologna'),

('Acquario di Genova', 'Genova'),
('Porto Antico', 'Genova'),

('Teatro Massimo', 'Palermo'),
('Cattedrale di Palermo', 'Palermo'),

('Arena di Verona', 'Verona'),
('Piazza delle Erbe', 'Verona');



-----------------------------------------------------
-- Comunicazioni Host/Lingue
-----------------------------------------------------


INSERT INTO Comunicazione VALUES ('Italiano','host01@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host01@email.it');


INSERT INTO Comunicazione VALUES ('Italiano','host02@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host02@email.it');
INSERT INTO Comunicazione VALUES ('Tedesco','host02@email.it');

INSERT INTO Comunicazione VALUES ('Russo','host03@email.it');
INSERT INTO Comunicazione VALUES ('Portoghese','host03@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host04@email.it');


INSERT INTO Comunicazione VALUES ('Italiano','host05@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host05@email.it');
INSERT INTO Comunicazione VALUES ('Arabo','host05@email.it');


INSERT INTO Comunicazione VALUES ('Italiano','host06@email.it');


INSERT INTO Comunicazione VALUES ('Italiano','host07@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host07@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host08@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host08@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host09@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host09@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host10@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host10@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host11@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host11@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host12@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host12@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host13@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host13@email.it');
INSERT INTO Comunicazione VALUES ('Spagnolo','host13@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host14@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host14@email.it');
INSERT INTO Comunicazione VALUES ('Spagnolo','host14@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host15@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host15@email.it');
INSERT INTO Comunicazione VALUES ('Spagnolo','host15@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host16@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host16@email.it');
INSERT INTO Comunicazione VALUES ('Spagnolo','host16@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host17@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host17@email.it');
INSERT INTO Comunicazione VALUES ('Spagnolo','host17@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host18@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host18@email.it');
INSERT INTO Comunicazione VALUES ('Spagnolo','host18@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host19@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host19@email.it');
INSERT INTO Comunicazione VALUES ('Francese','host19@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host20@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host20@email.it');
INSERT INTO Comunicazione VALUES ('Francese','host20@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host21@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host21@email.it');
INSERT INTO Comunicazione VALUES ('Francese','host21@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host22@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host22@email.it');
INSERT INTO Comunicazione VALUES ('Francese','host22@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host23@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host24@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host24@email.it');
INSERT INTO Comunicazione VALUES ('Francese','host24@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host25@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host25@email.it');
INSERT INTO Comunicazione VALUES ('Tedesco','host25@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host26@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host26@email.it');
INSERT INTO Comunicazione VALUES ('Russo','host26@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host27@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host27@email.it');
INSERT INTO Comunicazione VALUES ('Portoghese','host27@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host28@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host28@email.it');
INSERT INTO Comunicazione VALUES ('Francese','host28@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host29@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host29@email.it');
INSERT INTO Comunicazione VALUES ('Giapponese','host29@email.it');

INSERT INTO Comunicazione VALUES ('Italiano','host30@email.it');
INSERT INTO Comunicazione VALUES ('Inglese','host30@email.it');
INSERT INTO Comunicazione VALUES ('Cinese','host30@email.it');




-- ----------------
-- alloggioOfferta
-- ----------------
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio01');
INSERT INTO Offerta VALUES ('Colazione','Alloggio01');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio01');
INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio01');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio01');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio01');
INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio01');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio01');
INSERT INTO Offerta VALUES ('Spa','Alloggio01');

INSERT INTO Offerta VALUES ('Parcheggio','Alloggio02');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio02');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio02');
INSERT INTO Offerta VALUES ('Tv in camera','Alloggio02');
INSERT INTO Offerta VALUES ('Piscina','Alloggio02');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio02');
INSERT INTO Offerta VALUES ('Balcone','Alloggio02');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio02');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio02');

INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio03');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio03');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio03');
INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio03');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio03');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio03');
INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio03');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio03');
INSERT INTO Offerta VALUES ('Sauna','Alloggio03');

INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio04');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio04');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio04');
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio04');
INSERT INTO Offerta VALUES ('Colazione','Alloggio04');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio04');
INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio04');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio04');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio04');

INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio05');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio05');
INSERT INTO Offerta VALUES ('Spa','Alloggio05');
INSERT INTO Offerta VALUES ('Parcheggio','Alloggio05');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio05');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio05');
INSERT INTO Offerta VALUES ('Tv in camera','Alloggio05');
INSERT INTO Offerta VALUES ('Piscina','Alloggio05');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio05');

INSERT INTO Offerta VALUES ('Balcone','Alloggio06');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio06');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio06');
INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio06');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio06');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio06');
INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio06');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio06');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio06');

INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio07');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio07');
INSERT INTO Offerta VALUES ('Sauna','Alloggio07');
INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio07');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio07');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio07');
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio07');
INSERT INTO Offerta VALUES ('Colazione','Alloggio07');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio07');

INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio08');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio08');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio08');
INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio08');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio08');
INSERT INTO Offerta VALUES ('Spa','Alloggio08');
INSERT INTO Offerta VALUES ('Parcheggio','Alloggio08');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio08');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio08');

INSERT INTO Offerta VALUES ('Tv in camera','Alloggio09');
INSERT INTO Offerta VALUES ('Piscina','Alloggio09');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio09');
INSERT INTO Offerta VALUES ('Balcone','Alloggio09');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio09');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio09');
INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio09');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio09');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio09');

INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio10');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio10');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio10');
INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio10');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio10');
INSERT INTO Offerta VALUES ('Sauna','Alloggio10');
INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio10');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio10');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio10');
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio11');
INSERT INTO Offerta VALUES ('Colazione','Alloggio11');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio11');
INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio11');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio11');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio11');
INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio11');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio11');
INSERT INTO Offerta VALUES ('Spa','Alloggio11');

INSERT INTO Offerta VALUES ('Parcheggio','Alloggio12');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio12');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio12');
INSERT INTO Offerta VALUES ('Tv in camera','Alloggio12');
INSERT INTO Offerta VALUES ('Piscina','Alloggio12');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio12');
INSERT INTO Offerta VALUES ('Balcone','Alloggio12');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio12');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio12');

INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio13');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio13');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio13');
INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio13');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio13');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio13');
INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio13');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio13');
INSERT INTO Offerta VALUES ('Sauna','Alloggio13');

INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio14');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio14');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio14');
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio14');
INSERT INTO Offerta VALUES ('Colazione','Alloggio14');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio14');
INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio14');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio14');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio14');

INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio15');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio15');
INSERT INTO Offerta VALUES ('Spa','Alloggio15');
INSERT INTO Offerta VALUES ('Parcheggio','Alloggio15');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio15');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio15');
INSERT INTO Offerta VALUES ('Tv in camera','Alloggio15');
INSERT INTO Offerta VALUES ('Piscina','Alloggio15');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio15');

INSERT INTO Offerta VALUES ('Balcone','Alloggio16');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio16');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio16');
INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio16');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio16');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio16');
INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio16');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio16');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio16');

INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio17');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio17');
INSERT INTO Offerta VALUES ('Sauna','Alloggio17');
INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio17');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio17');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio17');
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio17');
INSERT INTO Offerta VALUES ('Colazione','Alloggio17');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio17');

INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio18');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio18');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio18');
INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio18');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio18');
INSERT INTO Offerta VALUES ('Spa','Alloggio18');
INSERT INTO Offerta VALUES ('Parcheggio','Alloggio18');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio18');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio18');

INSERT INTO Offerta VALUES ('Tv in camera','Alloggio19');
INSERT INTO Offerta VALUES ('Piscina','Alloggio19');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio19');
INSERT INTO Offerta VALUES ('Balcone','Alloggio19');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio19');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio19');
INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio19');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio19');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio19');

INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio20');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio20');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio20');
INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio20');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio20');
INSERT INTO Offerta VALUES ('Sauna','Alloggio20');
INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio20');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio20');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio20');

INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio21');
INSERT INTO Offerta VALUES ('Colazione','Alloggio21');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio21');
INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio21');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio21');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio21');
INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio21');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio21');
INSERT INTO Offerta VALUES ('Spa','Alloggio21');

INSERT INTO Offerta VALUES ('Parcheggio','Alloggio22');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio22');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio22');
INSERT INTO Offerta VALUES ('Tv in camera','Alloggio22');
INSERT INTO Offerta VALUES ('Piscina','Alloggio22');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio22');
INSERT INTO Offerta VALUES ('Balcone','Alloggio22');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio22');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio22');

INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio23');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio23');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio23');
INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio23');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio23');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio23');
INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio23');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio23');
INSERT INTO Offerta VALUES ('Sauna','Alloggio23');

INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio24');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio24');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio24');
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio24');
INSERT INTO Offerta VALUES ('Colazione','Alloggio24');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio24');
INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio24');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio24');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio24');

INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio25');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio25');
INSERT INTO Offerta VALUES ('Spa','Alloggio25');
INSERT INTO Offerta VALUES ('Parcheggio','Alloggio25');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio25');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio25');
INSERT INTO Offerta VALUES ('Tv in camera','Alloggio25');
INSERT INTO Offerta VALUES ('Piscina','Alloggio25');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio25');

INSERT INTO Offerta VALUES ('Balcone','Alloggio26');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio26');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio26');
INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio26');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio26');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio26');
INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio26');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio26');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio26');

INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio27');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio27');
INSERT INTO Offerta VALUES ('Sauna','Alloggio27');
INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio27');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio27');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio27');
INSERT INTO Offerta VALUES ('Wi-Fi','Alloggio27');
INSERT INTO Offerta VALUES ('Colazione','Alloggio27');
INSERT INTO Offerta VALUES ('Pulizia giornaliera','Alloggio27');

INSERT INTO Offerta VALUES ('Cucina attrezzata','Alloggio28');
INSERT INTO Offerta VALUES ('Accesso disabili','Alloggio28');
INSERT INTO Offerta VALUES ('Adatto a famiglie','Alloggio28');
INSERT INTO Offerta VALUES ('Animali ammessi','Alloggio28');
INSERT INTO Offerta VALUES ('Sala riunioni','Alloggio28');
INSERT INTO Offerta VALUES ('Spa','Alloggio28');
INSERT INTO Offerta VALUES ('Parcheggio','Alloggio28');
INSERT INTO Offerta VALUES ('Riscaldamento','Alloggio28');
INSERT INTO Offerta VALUES ('Aria condizionata','Alloggio28');

INSERT INTO Offerta VALUES ('Tv in camera','Alloggio29');
INSERT INTO Offerta VALUES ('Piscina','Alloggio29');
INSERT INTO Offerta VALUES ('Servizio navetta','Alloggio29');
INSERT INTO Offerta VALUES ('Balcone','Alloggio29');
INSERT INTO Offerta VALUES ('Lavatrice','Alloggio29');
INSERT INTO Offerta VALUES ('Asciugatrice','Alloggio29');
INSERT INTO Offerta VALUES ('Kit benvenuto','Alloggio29');
INSERT INTO Offerta VALUES ('Servizio lavanderia','Alloggio29');
INSERT INTO Offerta VALUES ('Colazione vegana','Alloggio29');

INSERT INTO Offerta VALUES ('Kit primo soccorso','Alloggio30');
INSERT INTO Offerta VALUES ('Deposito bagagli','Alloggio30');
INSERT INTO Offerta VALUES ('Mini bar','Alloggio30');
INSERT INTO Offerta VALUES ('Camere insonorizzate','Alloggio30');
INSERT INTO Offerta VALUES ('Cassetta di sicurezza','Alloggio30');
INSERT INTO Offerta VALUES ('Sauna','Alloggio30');
INSERT INTO Offerta VALUES ('Area giochi bambini','Alloggio30');
INSERT INTO Offerta VALUES ('Servizio baby-sitter','Alloggio30');
INSERT INTO Offerta VALUES ('Ginnastica/fitness','Alloggio30');



-----------------------------------------------------
-- Assegnazione dei Badge ai Superhost
-----------------------------------------------------
INSERT INTO Assegnazione (Host_email, Badge_ID) VALUES
('host19@email.it', 1),
('host20@email.it', 2),
('host21@email.it', 3),
('host22@email.it', 4),
('host23@email.it', 5),
('host24@email.it', 6);

-----------------------------------------------------
-- Recapiti Agenzie (6 numeri totali)
-----------------------------------------------------
INSERT INTO RecapitoTelefonicoAgenzia (numero, Agenzia_nome) VALUES
('064400001', 'AgenziaViaggiRoma'),
('064400002', 'AgenziaViaggiRoma'),
('028800001', 'TravelWorld'),
('028800002', 'TravelWorld'),
('055900001', 'HappyTour'),
('055900002', 'HappyTour');





-- recapiti utente
INSERT INTO RecapitoTelefonicoUtente (numero, Utente_email) VALUES
('320000001', 'utente01@email.it'),
('320000002', 'utente01@email.it'),
('320000003', 'utente02@email.it'),
('320000004', 'utente02@email.it'),
('320000005', 'utente03@email.it'),
('320000006', 'utente03@email.it'),
('320000007', 'utente04@email.it'),
('320000008', 'utente04@email.it'),
('320000009', 'utente05@email.it'),
('320000010', 'utente05@email.it'),
('320000011', 'utente06@email.it'),
('320000012', 'utente07@email.it'),
('320000013', 'utente08@email.it'),
('320000014', 'utente09@email.it'),
('320000015', 'utente10@email.it'),
('320000016', 'utente11@email.it'),
('320000017', 'utente12@email.it'),
('320000018', 'utente13@email.it'),
('320000019', 'utente14@email.it'),
('320000020', 'utente15@email.it'),
('320000021', 'utente16@email.it'),
('320000022', 'utente17@email.it'),
('320000023', 'utente18@email.it'),
('320000024', 'utente19@email.it'),
('320000025', 'utente20@email.it'),
('320000026', 'utente21@email.it'),
('320000027', 'utente22@email.it'),
('320000028', 'utente23@email.it'),
('320000029', 'utente24@email.it'),
('320000030', 'utente25@email.it'),
('320000031', 'utente26@email.it'),
('320000032', 'utente27@email.it'),
('320000033', 'utente28@email.it'),
('320000034', 'utente29@email.it'),
('320000035', 'utente30@email.it'),
('320000036', 'utente31@email.it'),
('320000037', 'utente32@email.it'),
('320000038', 'utente33@email.it'),
('320000039', 'utente34@email.it'),
('320000040', 'utente35@email.it'),
('320000041', 'utente36@email.it'),
('320000042', 'utente37@email.it'),
('320000043', 'utente38@email.it'),
('320000044', 'utente39@email.it'),
('320000045', 'utente40@email.it'),
('320000046', 'utente41@email.it'),
('320000047', 'utente42@email.it'),
('320000048', 'utente43@email.it'),
('320000049', 'utente44@email.it'),
('320000050', 'utente45@email.it'),
('320000051', 'utente46@email.it'),
('320000052', 'utente47@email.it'),
('320000053', 'utente48@email.it'),
('320000054', 'utente49@email.it'),
('320000055', 'utente50@email.it');



-----------------------------------------------------
-- Acquisti (50)
-----------------------------------------------------

INSERT INTO Acquisto (Esperienza_nome, Utente_email) VALUES
('Esperienza01','utente01@email.it'),
('Esperienza02','utente02@email.it'),
('Esperienza03','utente03@email.it'),
('Esperienza04','utente04@email.it'),
('Esperienza05','utente05@email.it'),
('Esperienza06','utente06@email.it'),
('Esperienza07','utente07@email.it'),
('Esperienza08','utente08@email.it'),
('Esperienza09','utente09@email.it'),
('Esperienza10','utente10@email.it'),

('Esperienza11','utente11@email.it'),
('Esperienza12','utente12@email.it'),
('Esperienza13','utente13@email.it'),
('Esperienza14','utente14@email.it'),
('Esperienza15','utente15@email.it'),
('Esperienza16','utente16@email.it'),
('Esperienza17','utente17@email.it'),
('Esperienza18','utente18@email.it'),
('Esperienza19','utente19@email.it'),
('Esperienza20','utente20@email.it'),

('Esperienza21','utente21@email.it'),
('Esperienza01','utente22@email.it'),
('Esperienza02','utente23@email.it'),
('Esperienza03','utente24@email.it'),
('Esperienza04','utente25@email.it'),
('Esperienza05','utente26@email.it'),
('Esperienza06','utente27@email.it'),
('Esperienza07','utente28@email.it'),
('Esperienza08','utente29@email.it'),
('Esperienza09','utente30@email.it'),

('Esperienza10','utente31@email.it'),
('Esperienza11','utente32@email.it'),
('Esperienza12','utente33@email.it'),
('Esperienza13','utente34@email.it'),
('Esperienza14','utente35@email.it'),
('Esperienza15','utente36@email.it'),
('Esperienza16','utente37@email.it'),
('Esperienza17','utente38@email.it'),
('Esperienza18','utente39@email.it'),
('Esperienza19','utente40@email.it'),

('Esperienza20','utente41@email.it'),
('Esperienza21','utente42@email.it'),
('Esperienza01','utente43@email.it'),
('Esperienza02','utente44@email.it'),
('Esperienza03','utente45@email.it'),
('Esperienza04','utente46@email.it'),
('Esperienza05','utente47@email.it'),
('Esperienza06','utente48@email.it'),
('Esperienza07','utente49@email.it'),
('Esperienza08','utente50@email.it');




-- --------------------
-- Prenotazioni(420)
-- -------------------
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-09', '2025-08-11', 19.25, 5, 197.03, 'Alloggio01', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-24', '2025-09-26', 8.14, 1, 304.98, 'Alloggio02', 'utente28@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-11', '2025-10-13', 2.6, 1, 284.41, 'Alloggio03', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-22', '2025-01-24', 15.0, 3, 408.0, 'Alloggio04', 'utente18@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-19', '2025-06-21', 18.23, 1, 248.58, 'Alloggio05', 'utente02@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-01', '2025-06-03', 19.25, 1, 184.11, 'Alloggio06', 'utente39@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-19', '2025-06-21', 6.21, 3, 358.28, 'Alloggio07', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-24', '2025-04-26', 7.16, 8, 235.81, 'Alloggio08', 'utente22@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-24', '2025-01-26', 9.1, 4, 170.89, 'Alloggio09', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-02', '2025-10-04', 6.77, 3, 464.29, 'Alloggio10', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-13', '2025-04-15', 8.02, 1, 207.87, 'Alloggio11', 'utente09@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-28', '2025-03-02', 11.11, 2, 277.34, 'Alloggio12', 'utente37@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-08', '2025-10-10', 2.62, 1, 455.74, 'Alloggio13', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-28', '2025-04-30', 18.84, 7, 399.31, 'Alloggio14', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-27', '2025-08-29', 4.02, 2, 299.46, 'Alloggio15', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-11', '2025-11-13', 17.31, 1, 358.87, 'Alloggio16', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-11', '2025-11-13', 8.21, 2, 279.04, 'Alloggio17', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-10', '2025-03-12', 5.76, 2, 316.65, 'Alloggio18', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-14', '2025-07-16', 13.13, 8, 170.27, 'Alloggio19', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-21', '2025-12-23', 14.77, 4, 385.24, 'Alloggio20', 'utente49@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-14', '2025-11-16', 9.84, 2, 126.22, 'Alloggio21', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-31', '2025-04-02', 13.61, 4, 146.86, 'Alloggio22', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-01', '2025-09-03', 11.47, 1, 414.32, 'Alloggio23', 'utente05@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-09', '2025-07-11', 18.86, 3, 352.15, 'Alloggio24', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-16', '2025-05-18', 1.45, 1, 400.11, 'Alloggio25', 'utente03@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-13', '2025-09-15', 3.41, 4, 397.95, 'Alloggio26', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-10', '2025-10-12', 8.58, 1, 248.66, 'Alloggio27', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-16', '2025-02-18', 15.22, 3, 110.21, 'Alloggio28', 'utente17@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-08', '2025-10-10', 0.3, 6, 291.12, 'Alloggio29', 'utente14@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-04', '2025-07-06', 15.34, 6, 167.63, 'Alloggio30', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-23', '2025-10-25', 6.01, 2, 212.42, 'Alloggio31', 'utente49@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-28', '2025-04-30', 15.53, 1, 417.28, 'Alloggio32', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-16', '2025-05-18', 9.02, 1, 436.7, 'Alloggio33', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-04', '2025-06-06', 13.05, 5, 273.02, 'Alloggio34', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-07', '2025-04-09', 8.9, 1, 287.88, 'Alloggio35', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-06', '2025-08-08', 13.41, 4, 180.11, 'Alloggio36', 'utente13@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-09', '2025-07-11', 8.12, 1, 411.62, 'Alloggio37', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-01', '2025-09-03', 18.5, 2, 133.66, 'Alloggio38', 'utente13@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-12', '2025-10-14', 17.23, 3, 357.57, 'Alloggio39', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-05', '2025-09-07', 10.1, 1, 364.99, 'Alloggio40', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-08', '2025-08-10', 19.18, 1, 226.3, 'Alloggio41', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-17', '2025-01-19', 8.86, 3, 180.46, 'Alloggio42', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-14', '2025-11-16', 16.7, 1, 199.92, 'Alloggio43', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-26', '2025-03-28', 8.7, 3, 363.37, 'Alloggio44', 'utente03@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-26', '2025-01-28', 3.82, 5, 342.4, 'Alloggio45', 'utente03@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-12', '2025-02-14', 8.69, 1, 264.8, 'Alloggio46', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-07', '2025-01-09', 3.64, 2, 264.03, 'Alloggio47', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-30', '2025-11-01', 4.05, 2, 445.21, 'Alloggio48', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-26', '2025-08-28', 6.85, 4, 303.67, 'Alloggio49', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-17', '2025-04-19', 12.5, 4, 259.0, 'Alloggio50', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-15', '2025-01-17', 15.66, 1, 355.91, 'Alloggio51', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-26', '2025-02-28', 3.33, 4, 264.88, 'Alloggio52', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-15', '2025-07-17', 2.53, 1, 105.27, 'Alloggio53', 'utente50@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-12', '2025-09-14', 0.8, 4, 176.58, 'Alloggio54', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-14', '2025-09-16', 2.6, 3, 212.33, 'Alloggio55', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-19', '2025-05-21', 5.45, 4, 308.23, 'Alloggio56', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-15', '2025-01-17', 7.54, 1, 342.1, 'Alloggio57', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-28', '2025-05-30', 15.77, 3, 367.24, 'Alloggio58', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-29', '2025-05-01', 14.91, 4, 168.48, 'Alloggio59', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-25', '2025-01-27', 8.18, 1, 203.84, 'Alloggio60', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-10', '2025-12-12', 1.79, 3, 239.63, 'Alloggio01', 'utente35@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-15', '2025-07-17', 5.71, 2, 313.04, 'Alloggio02', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-19', '2025-03-21', 14.33, 1, 250.16, 'Alloggio03', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-13', '2025-04-15', 5.55, 1, 453.36, 'Alloggio04', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-25', '2025-03-27', 7.86, 2, 280.11, 'Alloggio05', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-11', '2025-06-13', 10.5, 1, 204.06, 'Alloggio06', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-18', '2025-07-20', 17.03, 2, 316.95, 'Alloggio07', 'utente31@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-08', '2025-01-10', 3.18, 2, 245.92, 'Alloggio08', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-04', '2025-02-06', 10.88, 4, 167.55, 'Alloggio09', 'utente13@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-26', '2025-06-28', 15.24, 3, 422.1, 'Alloggio10', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-28', '2025-06-30', 7.78, 7, 208.42, 'Alloggio11', 'utente21@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-08', '2025-05-10', 2.3, 3, 304.82, 'Alloggio12', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-22', '2025-05-24', 14.29, 1, 401.12, 'Alloggio13', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-04', '2025-12-06', 2.22, 2, 481.08, 'Alloggio14', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-22', '2025-01-24', 7.11, 4, 289.82, 'Alloggio15', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-26', '2025-03-28', 0.68, 3, 431.05, 'Alloggio16', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-17', '2025-12-19', 15.83, 3, 255.88, 'Alloggio17', 'utente30@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-28', '2025-01-30', 10.25, 3, 301.56, 'Alloggio18', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-01', '2025-01-03', 19.4, 7, 157.98, 'Alloggio19', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-18', '2025-05-20', 18.31, 1, 369.24, 'Alloggio20', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-16', '2025-01-18', 19.71, 3, 112.41, 'Alloggio21', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-26', '2025-11-28', 12.45, 3, 148.83, 'Alloggio22', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-24', '2025-11-26', 2.7, 2, 455.36, 'Alloggio23', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-16', '2025-01-18', 10.11, 2, 390.12, 'Alloggio24', 'utente09@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-05', '2025-04-07', 15.36, 1, 343.64, 'Alloggio25', 'utente12@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-12', '2025-12-14', 5.5, 6, 389.34, 'Alloggio26', 'utente06@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-25', '2025-12-27', 12.34, 1, 238.44, 'Alloggio27', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-05', '2025-05-07', 0.86, 4, 128.88, 'Alloggio28', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-04', '2025-02-06', 2.77, 8, 283.91, 'Alloggio29', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-30', '2025-11-01', 15.39, 1, 167.53, 'Alloggio30', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-21', '2025-09-23', 11.38, 1, 200.28, 'Alloggio31', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-27', '2025-07-29', 16.41, 2, 412.93, 'Alloggio32', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-11', '2025-04-13', 7.52, 2, 443.9, 'Alloggio33', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-11', '2025-05-13', 19.77, 1, 251.92, 'Alloggio34', 'utente05@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-26', '2025-12-28', 12.62, 1, 276.12, 'Alloggio35', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-14', '2025-01-16', 8.78, 6, 189.74, 'Alloggio36', 'utente30@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-18', '2025-01-20', 16.3, 5, 374.98, 'Alloggio37', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-28', '2025-11-30', 2.55, 2, 159.82, 'Alloggio38', 'utente37@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-09', '2025-12-11', 12.53, 4, 377.87, 'Alloggio39', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-07', '2025-01-09', 12.74, 1, 354.28, 'Alloggio40', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-07', '2025-04-09', 15.11, 3, 237.69, 'Alloggio41', 'utente31@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-05', '2025-11-07', 6.39, 2, 185.35, 'Alloggio42', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-03', '2025-11-05', 15.91, 2, 201.82, 'Alloggio43', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-10', '2025-07-12', 6.25, 4, 373.12, 'Alloggio44', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-11', '2025-03-13', 12.48, 1, 311.57, 'Alloggio45', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-03', '2025-07-05', 10.19, 3, 260.45, 'Alloggio46', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-30', '2025-06-01', 8.75, 6, 250.03, 'Alloggio47', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-26', '2025-08-28', 18.48, 2, 378.25, 'Alloggio48', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-25', '2025-03-27', 17.32, 5, 269.54, 'Alloggio49', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-14', '2025-05-16', 10.07, 1, 266.19, 'Alloggio50', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-03', '2025-11-05', 9.1, 1, 383.6, 'Alloggio51', 'utente18@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-09', '2025-12-11', 12.15, 3, 240.71, 'Alloggio52', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-29', '2025-10-31', 9.54, 4, 97.7, 'Alloggio53', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-16', '2025-04-18', 8.74, 5, 162.44, 'Alloggio54', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-14', '2025-05-16', 16.14, 1, 182.81, 'Alloggio55', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-24', '2025-11-26', 11.36, 4, 288.97, 'Alloggio56', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-15', '2025-12-17', 2.3, 1, 361.49, 'Alloggio57', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-16', '2025-08-18', 18.34, 1, 356.04, 'Alloggio58', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-18', '2025-05-20', 6.19, 2, 185.74, 'Alloggio59', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-05', '2025-12-07', 18.75, 1, 180.38, 'Alloggio60', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-05', '2025-02-07', 16.98, 3, 202.57, 'Alloggio01', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-07', '2025-06-09', 0.2, 5, 331.34, 'Alloggio02', 'utente13@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-01', '2025-07-03', 14.2, 1, 250.54, 'Alloggio03', 'utente35@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-24', '2025-01-26', 19.85, 1, 384.72, 'Alloggio04', 'utente22@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-11', '2025-12-13', 7.01, 1, 282.69, 'Alloggio05', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-03', '2025-11-05', 12.59, 1, 199.29, 'Alloggio06', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-15', '2025-09-17', 2.02, 2, 374.28, 'Alloggio07', 'utente22@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-18', '2025-04-20', 16.5, 8, 212.09, 'Alloggio08', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-05', '2025-12-07', 13.11, 6, 163.35, 'Alloggio09', 'utente17@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-02', '2025-12-04', 8.68, 4, 454.77, 'Alloggio10', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-21', '2025-02-23', 5.6, 2, 213.34, 'Alloggio11', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-18', '2025-08-20', 7.87, 3, 287.45, 'Alloggio12', 'utente02@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-10', '2025-03-12', 18.17, 1, 382.96, 'Alloggio13', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-15', '2025-06-17', 17.16, 1, 407.57, 'Alloggio14', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-11', '2025-09-13', 5.59, 1, 294.56, 'Alloggio15', 'utente03@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-03', '2025-01-05', 12.12, 3, 381.4, 'Alloggio16', 'utente14@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-01', '2025-09-03', 13.75, 4, 262.2, 'Alloggio17', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-18', '2025-04-20', 5.55, 5, 317.35, 'Alloggio18', 'utente50@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-25', '2025-10-27', 8.69, 8, 178.97, 'Alloggio19', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-02', '2025-08-04', 4.76, 6, 430.48, 'Alloggio20', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-04', '2025-06-06', 3.63, 2, 134.92, 'Alloggio21', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-20', '2025-11-22', 4.96, 2, 161.57, 'Alloggio22', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-10', '2025-07-12', 11.15, 5, 415.82, 'Alloggio23', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-04', '2025-10-06', 4.51, 2, 414.43, 'Alloggio24', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-14', '2025-10-16', 5.0, 1, 385.7, 'Alloggio25', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-18', '2025-04-20', 16.62, 7, 343.53, 'Alloggio26', 'utente05@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-02', '2025-03-04', 12.25, 2, 238.68, 'Alloggio27', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-30', '2025-06-01', 13.21, 7, 112.83, 'Alloggio28', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-03', '2025-08-05', 10.47, 4, 261.43, 'Alloggio29', 'utente31@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-13', '2025-09-15', 4.81, 5, 188.48, 'Alloggio30', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-09', '2025-07-11', 7.45, 3, 209.16, 'Alloggio31', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-07', '2025-09-09', 14.46, 2, 422.57, 'Alloggio32', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-09', '2025-02-11', 13.84, 2, 413.57, 'Alloggio33', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-30', '2025-09-01', 19.02, 1, 254.28, 'Alloggio34', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-24', '2025-12-26', 19.26, 1, 255.14, 'Alloggio35', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-28', '2025-06-30', 17.89, 2, 170.79, 'Alloggio36', 'utente39@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-14', '2025-10-16', 17.47, 2, 369.73, 'Alloggio37', 'utente10@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-25', '2025-04-27', 9.02, 4, 149.21, 'Alloggio38', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-08', '2025-03-10', 11.53, 4, 382.19, 'Alloggio39', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-23', '2025-03-25', 11.96, 1, 357.44, 'Alloggio40', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-05', '2025-07-07', 3.33, 3, 270.68, 'Alloggio41', 'utente09@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-14', '2025-05-16', 14.68, 1, 168.93, 'Alloggio42', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-22', '2025-06-24', 19.98, 1, 192.05, 'Alloggio43', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-08', '2025-12-10', 4.97, 3, 378.22, 'Alloggio44', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-10', '2025-05-12', 5.06, 2, 337.99, 'Alloggio45', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-26', '2025-07-28', 0.77, 2, 287.77, 'Alloggio46', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-23', '2025-07-25', 5.67, 8, 258.46, 'Alloggio47', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-18', '2025-09-20', 17.83, 1, 381.27, 'Alloggio48', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-12', '2025-07-14', 1.72, 3, 320.39, 'Alloggio49', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-29', '2025-05-31', 16.04, 3, 248.52, 'Alloggio50', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-18', '2025-05-20', 0.06, 1, 421.75, 'Alloggio51', 'utente12@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-04', '2025-06-06', 3.02, 4, 265.73, 'Alloggio52', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-16', '2025-02-18', 4.63, 2, 103.0, 'Alloggio53', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-18', '2025-09-20', 0.56, 5, 177.0, 'Alloggio54', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-03', '2025-12-05', 13.0, 3, 189.66, 'Alloggio55', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-17', '2025-07-19', 16.92, 7, 270.84, 'Alloggio56', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-05', '2025-01-07', 4.31, 1, 354.05, 'Alloggio57', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-10', '2025-01-12', 4.29, 3, 417.3, 'Alloggio58', 'utente17@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-23', '2025-08-25', 16.84, 4, 164.66, 'Alloggio59', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-16', '2025-08-18', 5.49, 1, 209.81, 'Alloggio60', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-17', '2025-06-19', 7.93, 3, 224.65, 'Alloggio01', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-01', '2025-01-03', 5.4, 5, 314.07, 'Alloggio02', 'utente39@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-09', '2025-12-11', 4.6, 2, 278.57, 'Alloggio03', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-26', '2025-10-28', 0.19, 4, 479.09, 'Alloggio04', 'utente22@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-13', '2025-04-15', 18.66, 1, 247.27, 'Alloggio05', 'utente02@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-31', '2025-09-02', 13.17, 1, 197.97, 'Alloggio06', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-06', '2025-04-08', 5.36, 3, 361.52, 'Alloggio07', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-08', '2025-03-10', 0.45, 5, 252.86, 'Alloggio08', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-02', '2025-02-04', 9.99, 1, 169.22, 'Alloggio09', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-14', '2025-12-16', 16.2, 4, 417.32, 'Alloggio10', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-07', '2025-05-09', 4.27, 4, 216.35, 'Alloggio11', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-21', '2025-04-23', 18.97, 2, 252.81, 'Alloggio12', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-31', '2025-11-02', 6.13, 1, 439.31, 'Alloggio13', 'utente14@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-10', '2025-07-12', 2.79, 1, 478.27, 'Alloggio14', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-08', '2025-05-10', 13.75, 6, 269.1, 'Alloggio15', 'utente28@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-14', '2025-01-16', 7.28, 6, 402.4, 'Alloggio16', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-21', '2025-12-23', 5.86, 3, 286.19, 'Alloggio17', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-13', '2025-07-15', 14.81, 2, 286.24, 'Alloggio18', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-14', '2025-01-16', 3.61, 8, 188.92, 'Alloggio19', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-05', '2025-02-07', 11.81, 6, 398.62, 'Alloggio20', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-29', '2025-10-31', 7.08, 3, 130.09, 'Alloggio21', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-26', '2025-09-28', 19.51, 2, 136.83, 'Alloggio22', 'utente13@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-23', '2025-02-25', 13.09, 4, 406.74, 'Alloggio23', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-28', '2025-10-30', 6.0, 3, 407.96, 'Alloggio24', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-16', '2025-02-18', 19.78, 1, 325.69, 'Alloggio25', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-08', '2025-05-10', 15.5, 4, 348.14, 'Alloggio26', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-14', '2025-04-16', 1.86, 2, 266.94, 'Alloggio27', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-08', '2025-01-10', 1.99, 6, 127.41, 'Alloggio28', 'utente03@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-11', '2025-08-13', 0.19, 4, 291.45, 'Alloggio29', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-23', '2025-06-25', 19.88, 5, 158.64, 'Alloggio30', 'utente06@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-20', '2025-03-22', 11.73, 2, 199.49, 'Alloggio31', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-04', '2025-09-06', 6.61, 1, 461.35, 'Alloggio32', 'utente30@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-14', '2025-02-16', 16.52, 3, 400.7, 'Alloggio33', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-28', '2025-10-30', 18.85, 1, 254.81, 'Alloggio34', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-08', '2025-03-10', 12.07, 1, 277.86, 'Alloggio35', 'utente06@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-04', '2025-12-06', 16.93, 8, 172.79, 'Alloggio36', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-10', '2025-01-12', 2.23, 2, 438.01, 'Alloggio37', 'utente02@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-23', '2025-07-25', 9.79, 3, 147.94, 'Alloggio38', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-16', '2025-12-18', 18.35, 2, 352.73, 'Alloggio39', 'utente39@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-24', '2025-09-26', 14.8, 1, 345.91, 'Alloggio40', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-15', '2025-01-17', 5.66, 2, 264.15, 'Alloggio41', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-21', '2025-11-23', 11.64, 5, 174.95, 'Alloggio42', 'utente12@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-19', '2025-10-21', 17.41, 4, 198.22, 'Alloggio43', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-18', '2025-10-20', 4.26, 4, 381.05, 'Alloggio44', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-12', '2025-02-14', 4.51, 5, 339.94, 'Alloggio45', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-23', '2025-04-25', 10.92, 1, 258.33, 'Alloggio46', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-28', '2025-04-30', 19.99, 7, 219.23, 'Alloggio47', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-30', '2025-08-01', 18.35, 1, 378.86, 'Alloggio48', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-04', '2025-04-06', 7.34, 5, 302.07, 'Alloggio49', 'utente05@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-07', '2025-08-09', 14.47, 7, 253.17, 'Alloggio50', 'utente28@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-12', '2025-10-14', 16.45, 1, 352.58, 'Alloggio51', 'utente21@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-16', '2025-03-18', 10.76, 4, 244.52, 'Alloggio52', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-13', '2025-09-15', 17.53, 4, 89.07, 'Alloggio53', 'utente49@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-28', '2025-12-30', 13.29, 1, 154.34, 'Alloggio54', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-26', '2025-07-28', 3.5, 1, 210.37, 'Alloggio55', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-27', '2025-01-29', 4.77, 8, 310.45, 'Alloggio56', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-23', '2025-04-25', 2.59, 1, 360.42, 'Alloggio57', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-24', '2025-10-26', 0.44, 3, 434.08, 'Alloggio58', 'utente31@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-17', '2025-07-19', 19.24, 6, 159.9, 'Alloggio59', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-22', '2025-06-24', 11.08, 1, 197.4, 'Alloggio60', 'utente39@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-10', '2025-07-12', 9.8, 1, 220.09, 'Alloggio01', 'utente31@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-18', '2025-07-20', 4.79, 3, 316.1, 'Alloggio02', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-27', '2025-08-29', 13.18, 2, 253.51, 'Alloggio03', 'utente02@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-05', '2025-09-07', 0.24, 2, 478.85, 'Alloggio04', 'utente28@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-05', '2025-12-07', 16.09, 2, 255.09, 'Alloggio05', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-22', '2025-12-24', 2.59, 1, 222.09, 'Alloggio06', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-06', '2025-11-08', 10.02, 3, 343.72, 'Alloggio07', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-25', '2025-04-27', 2.57, 1, 247.47, 'Alloggio08', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-25', '2025-06-27', 5.52, 2, 177.62, 'Alloggio09', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-24', '2025-04-26', 15.59, 1, 420.36, 'Alloggio10', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-10', '2025-11-12', 8.26, 6, 207.33, 'Alloggio11', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-17', '2025-09-19', 17.52, 2, 257.34, 'Alloggio12', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-22', '2025-03-24', 12.82, 1, 408.0, 'Alloggio13', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-29', '2025-12-31', 10.0, 6, 442.8, 'Alloggio14', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-04', '2025-04-06', 3.44, 2, 301.27, 'Alloggio15', 'utente30@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-29', '2025-03-31', 5.48, 6, 410.22, 'Alloggio16', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-31', '2025-08-02', 11.61, 3, 268.71, 'Alloggio17', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-27', '2025-03-29', 7.16, 4, 311.94, 'Alloggio18', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-26', '2025-06-28', 15.61, 2, 165.4, 'Alloggio19', 'utente09@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-01', '2025-07-03', 1.33, 2, 445.99, 'Alloggio20', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-20', '2025-04-22', 11.23, 1, 124.28, 'Alloggio21', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-02', '2025-09-04', 13.99, 3, 146.22, 'Alloggio22', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-28', '2025-03-30', 9.93, 3, 421.53, 'Alloggio23', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-11', '2025-06-13', 9.93, 3, 390.9, 'Alloggio24', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-23', '2025-03-25', 12.57, 1, 354.97, 'Alloggio25', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-13', '2025-05-15', 10.93, 8, 366.97, 'Alloggio26', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-26', '2025-01-28', 6.54, 2, 254.21, 'Alloggio27', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-14', '2025-11-16', 6.33, 4, 121.77, 'Alloggio28', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-09', '2025-06-11', 18.42, 2, 238.21, 'Alloggio29', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-19', '2025-10-21', 5.45, 7, 187.21, 'Alloggio30', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-12', '2025-09-14', 3.03, 5, 219.15, 'Alloggio31', 'utente05@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-24', '2025-08-26', 9.76, 1, 445.79, 'Alloggio32', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-20', '2025-05-22', 2.32, 3, 468.86, 'Alloggio33', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-04', '2025-09-06', 6.11, 5, 294.81, 'Alloggio34', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-11', '2025-08-13', 14.49, 1, 270.21, 'Alloggio35', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-12', '2025-02-14', 15.59, 2, 175.57, 'Alloggio36', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-27', '2025-03-01', 15.52, 1, 378.47, 'Alloggio37', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-12', '2025-03-14', 14.82, 6, 139.7, 'Alloggio38', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-18', '2025-07-20', 6.62, 4, 403.4, 'Alloggio39', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-09', '2025-09-11', 6.9, 1, 377.99, 'Alloggio40', 'utente22@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-11', '2025-07-13', 13.3, 2, 242.76, 'Alloggio41', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-11', '2025-06-13', 17.6, 1, 163.15, 'Alloggio42', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-19', '2025-03-21', 9.48, 1, 217.25, 'Alloggio43', 'utente14@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-19', '2025-06-21', 2.79, 3, 386.9, 'Alloggio44', 'utente39@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-31', '2025-11-02', 5.29, 4, 337.17, 'Alloggio45', 'utente14@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-22', '2025-07-24', 13.04, 2, 252.18, 'Alloggio46', 'utente06@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-21', '2025-10-23', 7.54, 6, 253.34, 'Alloggio47', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-21', '2025-02-23', 14.18, 1, 398.2, 'Alloggio48', 'utente35@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-24', '2025-09-26', 0.08, 1, 325.74, 'Alloggio49', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-10', '2025-08-12', 2.57, 2, 288.39, 'Alloggio50', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-21', '2025-10-23', 1.31, 1, 416.47, 'Alloggio51', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-09', '2025-04-11', 17.44, 6, 226.21, 'Alloggio52', 'utente10@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-18', '2025-07-20', 9.26, 4, 98.0, 'Alloggio53', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-06', '2025-09-08', 16.7, 5, 148.27, 'Alloggio54', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-27', '2025-04-29', 18.84, 1, 176.93, 'Alloggio55', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-03', '2025-05-05', 1.91, 6, 319.77, 'Alloggio56', 'utente37@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-04', '2025-08-06', 10.4, 1, 331.52, 'Alloggio57', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-29', '2025-07-31', 5.56, 4, 411.76, 'Alloggio58', 'utente22@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-18', '2025-09-20', 12.9, 2, 172.46, 'Alloggio59', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-18', '2025-07-20', 19.57, 1, 178.55, 'Alloggio60', 'utente28@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-05', '2025-12-07', 10.29, 2, 218.89, 'Alloggio01', 'utente31@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-04', '2025-01-06', 9.87, 8, 299.23, 'Alloggio02', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-20', '2025-08-22', 2.72, 2, 284.06, 'Alloggio03', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-24', '2025-04-26', 15.29, 4, 406.61, 'Alloggio04', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-27', '2025-06-29', 17.99, 1, 249.31, 'Alloggio05', 'utente10@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-06', '2025-03-08', 13.34, 1, 197.58, 'Alloggio06', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-15', '2025-12-17', 11.81, 2, 336.89, 'Alloggio07', 'utente28@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-16', '2025-06-18', 15.91, 3, 213.59, 'Alloggio08', 'utente05@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-12', '2025-07-14', 9.23, 3, 170.65, 'Alloggio09', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-14', '2025-06-16', 1.02, 5, 492.92, 'Alloggio10', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-25', '2025-12-27', 13.71, 8, 195.02, 'Alloggio11', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-23', '2025-07-25', 17.25, 4, 258.18, 'Alloggio12', 'utente28@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-13', '2025-03-15', 15.11, 1, 397.29, 'Alloggio13', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-28', '2025-07-30', 9.71, 4, 444.23, 'Alloggio14', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-25', '2025-08-27', 17.58, 1, 257.15, 'Alloggio15', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-29', '2025-07-01', 12.57, 3, 379.45, 'Alloggio16', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-31', '2025-11-02', 2.92, 4, 295.12, 'Alloggio17', 'utente18@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-08', '2025-09-10', 17.02, 2, 278.81, 'Alloggio18', 'utente46@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-13', '2025-07-15', 13.34, 4, 169.85, 'Alloggio19', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-07', '2025-11-09', 16.75, 1, 376.29, 'Alloggio20', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-18', '2025-09-20', 5.62, 2, 132.13, 'Alloggio21', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-04', '2025-01-06', 18.45, 1, 138.63, 'Alloggio22', 'utente49@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-27', '2025-07-29', 6.65, 6, 436.88, 'Alloggio23', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-19', '2025-03-21', 6.17, 1, 407.22, 'Alloggio24', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-10', '2025-02-12', 6.26, 1, 380.58, 'Alloggio25', 'utente05@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-19', '2025-11-21', 19.62, 1, 331.17, 'Alloggio26', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-18', '2025-11-20', 7.24, 1, 252.31, 'Alloggio27', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-08', '2025-05-10', 14.11, 4, 111.66, 'Alloggio28', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-23', '2025-05-25', 13.12, 4, 253.69, 'Alloggio29', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-26', '2025-07-28', 6.04, 2, 186.04, 'Alloggio30', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-02', '2025-09-04', 12.33, 2, 198.13, 'Alloggio31', 'utente49@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-04', '2025-06-06', 0.61, 2, 490.99, 'Alloggio32', 'utente30@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-07', '2025-04-09', 4.17, 2, 459.98, 'Alloggio33', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-15', '2025-03-17', 13.55, 5, 271.45, 'Alloggio34', 'utente50@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-09', '2025-07-11', 8.18, 1, 290.15, 'Alloggio35', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-01', '2025-06-03', 13.4, 3, 180.13, 'Alloggio36', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-13', '2025-06-15', 17.72, 2, 368.61, 'Alloggio37', 'utente50@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-19', '2025-02-21', 2.16, 5, 160.46, 'Alloggio38', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-09', '2025-10-11', 2.4, 1, 421.63, 'Alloggio39', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-23', '2025-06-25', 11.52, 1, 359.23, 'Alloggio40', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-29', '2025-05-01', 2.96, 6, 271.71, 'Alloggio41', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-13', '2025-10-15', 14.84, 5, 168.62, 'Alloggio42', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-28', '2025-11-30', 7.26, 6, 222.58, 'Alloggio43', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-14', '2025-12-16', 4.66, 2, 379.45, 'Alloggio44', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-24', '2025-07-26', 17.38, 4, 294.13, 'Alloggio45', 'utente37@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-21', '2025-11-23', 18.17, 1, 237.31, 'Alloggio46', 'utente17@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-03', '2025-12-05', 8.05, 2, 251.94, 'Alloggio47', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-06', '2025-09-08', 13.82, 1, 399.88, 'Alloggio48', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-10', '2025-07-12', 0.99, 4, 322.77, 'Alloggio49', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-25', '2025-01-27', 12.4, 7, 259.3, 'Alloggio50', 'utente47@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-07', '2025-05-09', 0.9, 3, 418.2, 'Alloggio51', 'utente45@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-18', '2025-05-20', 5.68, 5, 258.44, 'Alloggio52', 'utente15@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-26', '2025-09-28', 5.12, 6, 102.47, 'Alloggio53', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-04', '2025-03-06', 2.11, 2, 174.24, 'Alloggio54', 'utente02@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-19', '2025-07-21', 11.91, 3, 192.04, 'Alloggio55', 'utente11@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-01', '2025-05-03', 0.52, 6, 324.3, 'Alloggio56', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-27', '2025-06-29', 3.91, 1, 355.53, 'Alloggio57', 'utente37@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-04', '2025-05-06', 1.39, 1, 429.94, 'Alloggio58', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-29', '2025-05-01', 17.09, 5, 164.16, 'Alloggio59', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-11', '2025-10-13', 0.46, 1, 220.98, 'Alloggio60', 'utente35@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-02', '2025-02-04', 10.98, 5, 217.21, 'Alloggio01', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-30', '2025-04-01', 5.15, 3, 314.9, 'Alloggio02', 'utente10@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-29', '2025-12-31', 7.24, 2, 270.86, 'Alloggio03', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-18', '2025-07-20', 8.5, 2, 439.2, 'Alloggio04', 'utente25@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-13', '2025-11-15', 16.78, 2, 252.99, 'Alloggio05', 'utente20@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-12', '2025-08-14', 18.62, 1, 185.55, 'Alloggio06', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-28', '2025-10-30', 3.98, 4, 366.8, 'Alloggio07', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-05', '2025-08-07', 3.67, 2, 244.68, 'Alloggio08', 'utente14@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-31', '2025-06-02', 4.55, 6, 179.45, 'Alloggio09', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-11', '2025-03-13', 2.26, 1, 486.75, 'Alloggio10', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-04', '2025-05-06', 15.32, 6, 191.38, 'Alloggio11', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-19', '2025-07-21', 17.1, 2, 258.65, 'Alloggio12', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-09', '2025-06-11', 0.27, 1, 466.74, 'Alloggio13', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-15', '2025-08-17', 12.9, 1, 428.53, 'Alloggio14', 'utente22@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-13', '2025-08-15', 12.75, 4, 272.22, 'Alloggio15', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-28', '2025-03-30', 4.02, 6, 416.55, 'Alloggio16', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-23', '2025-07-25', 13.55, 2, 262.81, 'Alloggio17', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-17', '2025-04-19', 2.33, 4, 328.17, 'Alloggio18', 'utente44@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-12', '2025-06-14', 19.67, 5, 157.45, 'Alloggio19', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-04', '2025-04-06', 16.82, 5, 375.97, 'Alloggio20', 'utente06@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-11', '2025-12-13', 17.44, 3, 115.58, 'Alloggio21', 'utente43@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-11-30', '2025-12-02', 0.43, 3, 169.27, 'Alloggio22', 'utente21@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-26', '2025-01-28', 12.63, 6, 408.89, 'Alloggio23', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-05-28', '2025-05-30', 0.35, 1, 432.48, 'Alloggio24', 'utente33@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-04', '2025-08-06', 19.59, 2, 326.46, 'Alloggio25', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-27', '2025-09-29', 18.08, 5, 337.51, 'Alloggio26', 'utente40@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-04', '2025-02-06', 18.65, 2, 221.27, 'Alloggio27', 'utente04@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-06', '2025-10-08', 8.9, 6, 118.43, 'Alloggio28', 'utente17@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-27', '2025-04-29', 10.65, 1, 260.9, 'Alloggio29', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-03', '2025-10-05', 7.64, 2, 182.87, 'Alloggio30', 'utente24@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-06', '2025-07-08', 6.73, 2, 210.79, 'Alloggio31', 'utente41@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-04', '2025-02-06', 19.02, 1, 400.04, 'Alloggio32', 'utente31@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-12', '2025-02-14', 13.95, 3, 413.04, 'Alloggio33', 'utente32@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-22', '2025-06-24', 11.85, 2, 276.79, 'Alloggio34', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-27', '2025-03-01', 0.05, 1, 315.84, 'Alloggio35', 'utente23@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-02', '2025-09-04', 14.6, 1, 177.63, 'Alloggio36', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-30', '2025-05-02', 13.46, 2, 387.7, 'Alloggio37', 'utente19@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-25', '2025-12-27', 1.42, 2, 161.67, 'Alloggio38', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-15', '2025-07-17', 0.83, 1, 428.41, 'Alloggio39', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-21', '2025-06-23', 12.37, 1, 355.78, 'Alloggio40', 'utente06@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-02-06', '2025-02-08', 2.21, 6, 273.81, 'Alloggio41', 'utente49@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-28', '2025-06-30', 2.47, 1, 193.11, 'Alloggio42', 'utente01@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-01-22', '2025-01-24', 12.96, 2, 208.9, 'Alloggio43', 'utente08@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-24', '2025-04-26', 11.26, 3, 353.19, 'Alloggio44', 'utente03@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-09', '2025-06-11', 4.52, 3, 339.91, 'Alloggio45', 'utente50@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-13', '2025-09-15', 6.66, 3, 270.69, 'Alloggio46', 'utente26@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-10-08', '2025-10-10', 12.04, 3, 241.01, 'Alloggio47', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-21', '2025-04-23', 16.02, 1, 389.67, 'Alloggio48', 'utente29@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-02', '2025-07-04', 15.54, 4, 275.34, 'Alloggio49', 'utente38@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-27', '2025-07-29', 6.53, 3, 276.67, 'Alloggio50', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-12-31', '2026-01-02', 3.65, 1, 406.6, 'Alloggio51', 'utente42@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-06-24', '2025-06-26', 4.61, 5, 261.37, 'Alloggio52', 'utente34@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-03', '2025-04-05', 13.93, 3, 92.96, 'Alloggio53', 'utente27@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-26', '2025-03-28', 1.05, 6, 176.13, 'Alloggio54', 'utente48@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-09-16', '2025-09-18', 19.32, 1, 175.88, 'Alloggio55', 'utente39@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-07-31', '2025-08-02', 1.17, 1, 322.19, 'Alloggio56', 'utente35@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-04-24', '2025-04-26', 11.55, 1, 327.26, 'Alloggio57', 'utente07@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-03-06', '2025-03-08', 14.61, 4, 372.3, 'Alloggio58', 'utente36@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-06', '2025-08-08', 19.47, 3, 159.45, 'Alloggio59', 'utente16@email.it');
INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email) VALUES ('2025-08-12', '2025-08-14', 14.38, 1, 190.08, 'Alloggio60', 'utente15@email.it');

-- --------------
-- Recensioni(168)
-- --------------

INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-31', 248, 'Recensione 248 del soggiorno', 2, 4, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-24', 373, 'Recensione 373 del soggiorno', 5, 4, 2, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-05', 260, 'Recensione 260 del soggiorno', 4, 1, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-19', 190, 'Recensione 190 del soggiorno', 4, 3, 1, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-14', 18, 'Recensione 18 del soggiorno', 3, 2, 2, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-03', 168, 'Recensione 168 del soggiorno', 3, 3, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-22', 298, 'Recensione 298 del soggiorno', 5, 5, 2, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-07', 279, 'Recensione 279 del soggiorno', 1, 1, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-24', 305, 'Recensione 305 del soggiorno', 2, 3, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-18', 291, 'Recensione 291 del soggiorno', 4, 1, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-08', 12, 'Recensione 12 del soggiorno', 1, 4, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-11', 265, 'Recensione 265 del soggiorno', 5, 4, 5, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-24', 294, 'Recensione 294 del soggiorno', 3, 3, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-18', 60, 'Recensione 60 del soggiorno', 1, 5, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-02', 177, 'Recensione 177 del soggiorno', 2, 5, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-10', 145, 'Recensione 145 del soggiorno', 1, 3, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-10', 65, 'Recensione 65 del soggiorno', 5, 1, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-23', 222, 'Recensione 222 del soggiorno', 2, 1, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-08', 277, 'Recensione 277 del soggiorno', 2, 5, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-11', 132, 'Recensione 132 del soggiorno', 4, 2, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-12', 172, 'Recensione 172 del soggiorno', 5, 3, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-30', 51, 'Recensione 51 del soggiorno', 5, 2, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-06', 138, 'Recensione 138 del soggiorno', 1, 5, 1, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-07', 161, 'Recensione 161 del soggiorno', 2, 1, 5, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-01', 151, 'Recensione 151 del soggiorno', 2, 3, 2, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-29', 174, 'Recensione 174 del soggiorno', 1, 1, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-09', 76, 'Recensione 76 del soggiorno', 4, 3, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-06', 122, 'Recensione 122 del soggiorno', 1, 2, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-12', 354, 'Recensione 354 del soggiorno', 1, 3, 5, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-23', 2, 'Recensione 2 del soggiorno', 4, 1, 1, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-07', 335, 'Recensione 335 del soggiorno', 4, 3, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-19', 241, 'Recensione 241 del soggiorno', 5, 4, 2, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-16', 301, 'Recensione 301 del soggiorno', 3, 4, 4, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-18', 284, 'Recensione 284 del soggiorno', 5, 1, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-22', 419, 'Recensione 419 del soggiorno', 2, 3, 5, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-28', 405, 'Recensione 405 del soggiorno', 3, 4, 2, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-31', 155, 'Recensione 155 del soggiorno', 5, 2, 5, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-28', 16, 'Recensione 16 del soggiorno', 2, 1, 5, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-02', 116, 'Recensione 116 del soggiorno', 4, 2, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-21', 110, 'Recensione 110 del soggiorno', 2, 2, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-07', 113, 'Recensione 113 del soggiorno', 3, 3, 5, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-17', 141, 'Recensione 141 del soggiorno', 5, 4, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-27', 13, 'Recensione 13 del soggiorno', 2, 3, 4, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-25', 303, 'Recensione 303 del soggiorno', 3, 1, 4, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-06', 104, 'Recensione 104 del soggiorno', 1, 5, 4, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-24', 276, 'Recensione 276 del soggiorno', 1, 3, 5, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-10', 153, 'Recensione 153 del soggiorno', 2, 5, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-22', 223, 'Recensione 223 del soggiorno', 5, 2, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-28', 273, 'Recensione 273 del soggiorno', 3, 2, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-28', 255, 'Recensione 255 del soggiorno', 4, 3, 5, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-24', 146, 'Recensione 146 del soggiorno', 3, 4, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-16', 332, 'Recensione 332 del soggiorno', 4, 3, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-11', 103, 'Recensione 103 del soggiorno', 1, 5, 1, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-18', 35, 'Recensione 35 del soggiorno', 5, 3, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-31', 163, 'Recensione 163 del soggiorno', 5, 4, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-20', 290, 'Recensione 290 del soggiorno', 2, 1, 3, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-29', 281, 'Recensione 281 del soggiorno', 4, 5, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-21', 114, 'Recensione 114 del soggiorno', 2, 5, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-28', 261, 'Recensione 261 del soggiorno', 5, 3, 2, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-01', 205, 'Recensione 205 del soggiorno', 1, 5, 4, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-02', 309, 'Recensione 309 del soggiorno', 1, 1, 5, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-07', 70, 'Recensione 70 del soggiorno', 4, 1, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-12', 382, 'Recensione 382 del soggiorno', 5, 4, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-23', 50, 'Recensione 50 del soggiorno', 1, 2, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-26', 192, 'Recensione 192 del soggiorno', 4, 3, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-03', 311, 'Recensione 311 del soggiorno', 1, 4, 4, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-30', 39, 'Recensione 39 del soggiorno', 5, 4, 5, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-20', 338, 'Recensione 338 del soggiorno', 2, 3, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-28', 360, 'Recensione 360 del soggiorno', 3, 1, 2, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-15', 140, 'Recensione 140 del soggiorno', 1, 3, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-16', 408, 'Recensione 408 del soggiorno', 3, 3, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-11', 185, 'Recensione 185 del soggiorno', 4, 5, 3, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-27', 397, 'Recensione 397 del soggiorno', 1, 3, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-02', 181, 'Recensione 181 del soggiorno', 3, 5, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-29', 348, 'Recensione 348 del soggiorno', 5, 5, 2, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-18', 386, 'Recensione 386 del soggiorno', 3, 2, 2, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-28', 366, 'Recensione 366 del soggiorno', 5, 4, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-28', 375, 'Recensione 375 del soggiorno', 2, 1, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-16', 131, 'Recensione 131 del soggiorno', 2, 3, 3, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-02', 220, 'Recensione 220 del soggiorno', 4, 4, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-08', 371, 'Recensione 371 del soggiorno', 5, 3, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-30', 379, 'Recensione 379 del soggiorno', 2, 1, 2, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-17', 330, 'Recensione 330 del soggiorno', 3, 3, 5, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-29', 347, 'Recensione 347 del soggiorno', 3, 3, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-12', 210, 'Recensione 210 del soggiorno', 2, 3, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-08', 342, 'Recensione 342 del soggiorno', 1, 5, 3, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-15', 337, 'Recensione 337 del soggiorno', 4, 4, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-23', 370, 'Recensione 370 del soggiorno', 4, 1, 4, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-21', 372, 'Recensione 372 del soggiorno', 3, 1, 3, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-14', 34, 'Recensione 34 del soggiorno', 2, 3, 1, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-13', 339, 'Recensione 339 del soggiorno', 3, 3, 3, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-08', 387, 'Recensione 387 del soggiorno', 1, 2, 2, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-01', 271, 'Recensione 271 del soggiorno', 2, 5, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-18', 95, 'Recensione 95 del soggiorno', 2, 4, 4, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-12', 416, 'Recensione 416 del soggiorno', 2, 1, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-18', 4, 'Recensione 4 del soggiorno', 4, 5, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-08', 188, 'Recensione 188 del soggiorno', 1, 4, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-18', 15, 'Recensione 15 del soggiorno', 3, 3, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-28', 137, 'Recensione 137 del soggiorno', 2, 5, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-29', 52, 'Recensione 52 del soggiorno', 3, 1, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-05', 215, 'Recensione 215 del soggiorno', 1, 2, 5, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-25', 302, 'Recensione 302 del soggiorno', 5, 3, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-19', 191, 'Recensione 191 del soggiorno', 3, 2, 5, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-04', 378, 'Recensione 378 del soggiorno', 5, 1, 2, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-22', 267, 'Recensione 267 del soggiorno', 4, 2, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-26', 300, 'Recensione 300 del soggiorno', 5, 3, 5, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-27', 176, 'Recensione 176 del soggiorno', 2, 4, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-03', 237, 'Recensione 237 del soggiorno', 2, 4, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-03', 349, 'Recensione 349 del soggiorno', 1, 4, 5, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-07', 22, 'Recensione 22 del soggiorno', 1, 5, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-10', 336, 'Recensione 336 del soggiorno', 4, 4, 4, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-19', 356, 'Recensione 356 del soggiorno', 2, 4, 2, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-27', 162, 'Recensione 162 del soggiorno', 2, 5, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-15', 412, 'Recensione 412 del soggiorno', 2, 4, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-08', 69, 'Recensione 69 del soggiorno', 2, 3, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-24', 40, 'Recensione 40 del soggiorno', 1, 4, 5, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-13', 228, 'Recensione 228 del soggiorno', 2, 2, 5, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-04', 351, 'Recensione 351 del soggiorno', 4, 5, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-18', 393, 'Recensione 393 del soggiorno', 4, 3, 5, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-08', 345, 'Recensione 345 del soggiorno', 4, 1, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-07', 384, 'Recensione 384 del soggiorno', 3, 3, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-13', 369, 'Recensione 369 del soggiorno', 4, 1, 4, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-11', 376, 'Recensione 376 del soggiorno', 4, 4, 1, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-06', 415, 'Recensione 415 del soggiorno', 2, 3, 3, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-10', 99, 'Recensione 99 del soggiorno', 4, 4, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-29', 313, 'Recensione 313 del soggiorno', 2, 4, 5, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-23', 398, 'Recensione 398 del soggiorno', 4, 2, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-06', 319, 'Recensione 319 del soggiorno', 2, 3, 4, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-20', 28, 'Recensione 28 del soggiorno', 3, 2, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-16', 312, 'Recensione 312 del soggiorno', 2, 4, 3, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-21', 150, 'Recensione 150 del soggiorno', 2, 4, 4, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-16', 8, 'Recensione 8 del soggiorno', 1, 1, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-24', 169, 'Recensione 169 del soggiorno', 4, 1, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-19', 333, 'Recensione 333 del soggiorno', 2, 3, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-18', 1, 'Recensione 1 del soggiorno', 1, 3, 4, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-25', 3, 'Recensione 3 del soggiorno', 2, 1, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-16', 165, 'Recensione 165 del soggiorno', 1, 3, 5, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-14', 171, 'Recensione 171 del soggiorno', 5, 4, 5, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-08', 105, 'Recensione 105 del soggiorno', 2, 3, 4, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-01', 64, 'Recensione 64 del soggiorno', 5, 3, 4, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-22', 221, 'Recensione 221 del soggiorno', 1, 1, 3, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-12-02', 23, 'Recensione 23 del soggiorno', 3, 3, 5, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-24', 129, 'Recensione 129 del soggiorno', 3, 3, 3, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-24', 54, 'Recensione 54 del soggiorno', 4, 3, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-09-02', 246, 'Recensione 246 del soggiorno', 2, 3, 2, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-14', 130, 'Recensione 130 del soggiorno', 5, 5, 1, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-11', 125, 'Recensione 125 del soggiorno', 5, 1, 5, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-08-01', 25, 'Recensione 25 del soggiorno', 5, 5, 1, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-12', 318, 'Recensione 318 del soggiorno', 4, 2, 1, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-08', 208, 'Recensione 208 del soggiorno', 2, 5, 3, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-21', 320, 'Recensione 320 del soggiorno', 4, 2, 5, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-05-25', 109, 'Recensione 109 del soggiorno', 3, 5, 4, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-16', 359, 'Recensione 359 del soggiorno', 4, 4, 5, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-03', 121, 'Recensione 121 del soggiorno', 2, 1, 2, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-02-02', 147, 'Recensione 147 del soggiorno', 3, 2, 5, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-03', 128, 'Recensione 128 del soggiorno', 5, 3, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-06-10', 156, 'Recensione 156 del soggiorno', 1, 3, 2, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-22', 343, 'Recensione 343 del soggiorno', 3, 4, 4, 3);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-22', 233, 'Recensione 233 del soggiorno', 5, 3, 1, 4);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-20', 204, 'Recensione 204 del soggiorno', 3, 3, 5, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-11-28', 74, 'Recensione 74 del soggiorno', 4, 3, 2, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-30', 17, 'Recensione 17 del soggiorno', 2, 5, 3, 1);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-03-18', 213, 'Recensione 213 del soggiorno', 5, 2, 1, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-04-07', 396, 'Recensione 396 del soggiorno', 5, 1, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-01-11', 218, 'Recensione 218 del soggiorno', 2, 4, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-05', 182, 'Recensione 182 del soggiorno', 5, 5, 4, 5);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-07-20', 92, 'Recensione 92 del soggiorno', 1, 2, 2, 2);
INSERT INTO Recensione (data, Prenotazione_ID, testo_descrittivo, pulizia, qualita_alloggio, precisione_annuncio, disponibilita) VALUES ('2025-10-31', 115, 'Recensione 115 del soggiorno', 2, 5, 4, 5);