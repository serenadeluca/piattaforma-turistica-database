

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

  private static final String URL = 
    "jdbc:mysql://localhost:3306/piattaformaturistica?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";


    private static final String USER = "root"; 
    private static final String PASSWORD = "Db!2025_Serena";

    private static Connection connection = null;

    // Metodo per ottenere la connessione
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Connessione al database riuscita.");
            } catch (ClassNotFoundException e) {
                System.err.println("Driver JDBC non trovato.");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println("Errore nella connessione al database.");
                throw e;
            }
        }
        return connection;
    }

    // Metodo per chiudere la connessione
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Connessione chiusa.");
            }
        } catch (SQLException e) {
            System.err.println("Errore durante la chiusura della connessione.");
            e.printStackTrace();
        }
    }
}
