import java.sql.*;

public class Operazioni {

    // 1. Registrazione nuova prenotazione
    public static void registraPrenotazione(Date inizio, Date fine, double sconto, int ospiti,
                                            double costoTotale, String alloggioNome, String utenteEmail) {

        String sql = """
            INSERT INTO Prenotazione (data_inizio, data_fine, sconto, numero_ospiti, costo_totale, Alloggio_nome, Utente_email)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, inizio);
            ps.setDate(2, fine);
            ps.setDouble(3, sconto);
            ps.setInt(4, ospiti);
            ps.setDouble(5, costoTotale);
            ps.setString(6, alloggioNome);
            ps.setString(7, utenteEmail);

            ps.executeUpdate();
            System.out.println("Prenotazione registrata con successo.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 2. Prenotazione esperienza (Acquisto)
    public static void prenotaEsperienza(String esperienzaNome, String utenteEmail) {

        String sql = """
            INSERT INTO Acquisto (Esperienza_nome, Utente_email)
            VALUES (?, ?)
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, esperienzaNome);
            ps.setString(2, utenteEmail);

            ps.executeUpdate();
            System.out.println("Esperienza prenotata con successo.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 3. Aggiunta nuovo alloggio
    public static void aggiungiAlloggio(String nome, String tipo, String indirizzo, int piani, int locali,
                                        int mq, int maxOspiti, String descrizione, boolean animali,
                                        Boolean bagnoPrivato, Boolean giardino, String genere,
                                        String linkFoto, String hostEmail, String cittaNome,
                                        double costoPerNotte) {

        String sql = """
            INSERT INTO Alloggio (nome, tipo, indirizzo, piani, locali, mq, max_ospiti, descrizione,
                                  ammissione_animali, bagno_privato, giardino, genere, link_foto,
                                  Host_email, Citta_nome, costo_per_notte)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nome);
            ps.setString(2, tipo);
            ps.setString(3, indirizzo);
            ps.setInt(4, piani);
            ps.setInt(5, locali);
            ps.setInt(6, mq);
            ps.setInt(7, maxOspiti);
            ps.setString(8, descrizione);
            ps.setBoolean(9, animali);
            ps.setObject(10, bagnoPrivato);
            ps.setObject(11, giardino);
            ps.setString(12, genere);
            ps.setString(13, linkFoto);
            ps.setString(14, hostEmail);
            ps.setString(15, cittaNome);
            ps.setDouble(16, costoPerNotte);

            ps.executeUpdate();
            System.out.println("Alloggio aggiunto con successo.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 4. Aggiunta servizio a un alloggio
    public static void aggiungiServizioAlloggio(String servizioNome, String alloggioNome) {

        String sql = """
            INSERT INTO Offerta (Servizio_nome, Alloggio_nome)
            VALUES (?, ?)
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, servizioNome);
            ps.setString(2, alloggioNome);

            ps.executeUpdate();
            System.out.println("Servizio aggiunto all'alloggio.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 5. Modifica numero locali per gli alloggi di tipo "appartamento"
    public static void modificaLocali(String alloggioNome, int nuoviLocali) {

        String sql = """
            UPDATE Alloggio
            SET locali = ?
            WHERE nome = ?
            AND tipo = 'appartamento'
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, nuoviLocali);
            ps.setString(2, alloggioNome);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Locali aggiornati correttamente.");
            } else {
                System.out.println("Nessun aggiornamento effettuato. L'alloggio non esiste o non è un appartamento.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 6. Stampa prenotazioni (compreso l'importo totale)
    public static void stampaPrenotazioni() {

        String sql = """
            SELECT *
            FROM Prenotazione
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            double totale = 0;

            while (rs.next()) {
                System.out.println(
                    "ID: " + rs.getInt("ID") +
                    ", Alloggio: " + rs.getString("Alloggio_nome") +
                    ", Utente: " + rs.getString("Utente_email") +
                    ", Dal: " + rs.getDate("data_inizio") +
                    ", Al: " + rs.getDate("data_fine") +
                    ", Ospiti: " + rs.getInt("numero_ospiti") +
                    ", Totale: " + rs.getDouble("costo_totale")
                );
               
            }

           

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 7. Host professionisti di una agenzia
    public static void stampaProfessionistiAgenzia(String agenziaNome) {

        String sql = """
            SELECT * FROM Host
            WHERE tipo_host = 'host professionista'
            AND Agenzia_nome = ?
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, agenziaNome);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(
                    "Host: " + rs.getString("email") +
                    ", Nazionalità: " + rs.getString("nazionalita") +
                    ", Tasso risposta: " + rs.getDouble("tasso_risposta")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 8. Utenti con numero prenotazioni
    public static void stampaUtentiConPrenotazioni() {

        String sql = """
            SELECT u.email, u.nome, u.cognome, COUNT(p.ID) AS totale
            FROM Utente u
            LEFT JOIN Prenotazione p ON u.email = p.Utente_email
            GROUP BY u.email, u.nome, u.cognome
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                    rs.getString("nome") + " " + rs.getString("cognome") +
                    " → Prenotazioni: " + rs.getInt("totale")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 9. Numero alloggi per host
    public static void stampaAlloggiPerHost() {

        String sql = """
            SELECT h.email, COUNT(a.nome) AS totale
            FROM Host h
            LEFT JOIN Alloggio a ON h.email = a.Host_email
            GROUP BY h.email
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                    "Host: " + rs.getString("email") +
                    " → Alloggi gestiti: " + rs.getInt("totale")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 10. Alloggi disponibili in range date e con almeno N ospiti
    public static void alloggiDisponibili(Date inizio, Date fine, int ospitiMin) {

        String sql = """
            SELECT *
            FROM Alloggio a
            WHERE a.max_ospiti >= ?
            AND a.nome NOT IN (
                SELECT Alloggio_nome
                FROM Prenotazione
                WHERE ? < data_fine
                  AND ? > data_inizio
            )
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, ospitiMin);
            ps.setDate(2, inizio);
            ps.setDate(3, fine);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println("Alloggio disponibile: " + rs.getString("nome"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 11. Utenti con almeno 30 giorni prenotati
    public static void utentiCon30Giorni() {

        String sql = """
            SELECT u.email, u.nome, u.cognome,
                   SUM(DATEDIFF(p.data_fine, p.data_inizio) + 1) AS giorni
            FROM Utente u
            JOIN Prenotazione p ON u.email = p.Utente_email
            GROUP BY u.email, u.nome, u.cognome
            HAVING giorni >= 30
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                    rs.getString("nome") + " " + rs.getString("cognome") +
                    " → Giorni prenotati: " + rs.getInt("giorni")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 12. Rating medio host
    public static void ratingMedioHost() {

        String sql = """
            SELECT h.email,
                   AVG(r.disponibilita) AS disponibilita,
                   AVG(r.qualita_alloggio) AS qualita,
                   AVG(r.precisione_annuncio) AS precisione,
                   AVG(r.pulizia) AS pulizia
            FROM Host h
            JOIN Alloggio a ON h.email = a.Host_email
            JOIN Prenotazione p ON a.nome = p.Alloggio_nome
            JOIN Recensione r ON p.ID = r.Prenotazione_ID
            GROUP BY h.email
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                    "Host: " + rs.getString("email") +
                    " → Disponibilità: " + rs.getDouble("disponibilita") +
                    ", Qualità: " + rs.getDouble("qualita") +
                    ", Precisione: " + rs.getDouble("precisione") +
                    ", Pulizia: " + rs.getDouble("pulizia")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 13. Classifica host per numero recensioni
    public static void classificaHost() {

        String sql = """
            SELECT h.email, COUNT(r.Prenotazione_ID) AS recensioni
            FROM Host h
            JOIN Alloggio a ON h.email = a.Host_email
            JOIN Prenotazione p ON a.nome = p.Alloggio_nome
            JOIN Recensione r ON p.ID = r.Prenotazione_ID
            GROUP BY h.email
            ORDER BY recensioni DESC
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                    "Host: " + rs.getString("email") +
                    " → Recensioni: " + rs.getInt("recensioni")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 14. Alloggi con almeno 30 ospiti totali
    public static void alloggiCon30Ospiti() {

        String sql = """
            SELECT a.nome, a.descrizione, SUM(p.numero_ospiti) AS totale
            FROM Alloggio a
            JOIN Prenotazione p ON a.nome = p.Alloggio_nome
            GROUP BY a.nome, a.descrizione
            HAVING totale >= 30
            ORDER BY totale DESC
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                    rs.getString("nome") +
                    " → Ospiti totali: " + rs.getInt("totale") +
                    "\nDescrizione: " + rs.getString("descrizione")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 15. Utenti che non hanno prenotato esperienze
    public static void utentiSenzaEsperienze() {

        String sql = """
            SELECT u.email, u.nome, u.cognome
            FROM Utente u
            LEFT JOIN Acquisto a ON u.email = a.Utente_email
            WHERE a.Utente_email IS NULL
        """;

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(
                    rs.getString("nome") + " " + rs.getString("cognome")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
