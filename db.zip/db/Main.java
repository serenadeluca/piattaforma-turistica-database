import java.sql.Date;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int scelta = -1;

        while (scelta != 0) {

            System.out.println();
            System.out.println("===== MENU OPERAZIONI =====");
            System.out.println("1. Registrazione nuova prenotazione");
            System.out.println("2. Prenotazione esperienza");
            System.out.println("3. Aggiunta nuovo alloggio");
            System.out.println("4. Aggiunta servizio a un alloggio");
            System.out.println("5. Modifica numero locali di un alloggio");
            System.out.println("6. Stampa tutte le prenotazioni");
            System.out.println("7. Stampa professionisti di una agenzia");
            System.out.println("8. Stampa utenti con numero prenotazioni");
            System.out.println("9. Stampa numero alloggi per host");
            System.out.println("10. Ricerca alloggi disponibili");
            System.out.println("11. Utenti con almeno 30 giorni prenotati");
            System.out.println("12. Rating medio host");
            System.out.println("13. Classifica host per recensioni");
            System.out.println("14. Alloggi con almeno 30 ospiti");
            System.out.println("15. Utenti senza esperienze");
            System.out.println("0. Esci");
            System.out.print("Scelta: ");

            scelta = sc.nextInt();
            sc.nextLine();

            switch (scelta) {

                case 1 -> {
                    System.out.print("Data inizio (YYYY-MM-DD): ");
                    Date inizio = Date.valueOf(sc.nextLine());

                    System.out.print("Data fine (YYYY-MM-DD): ");
                    Date fine = Date.valueOf(sc.nextLine());

                    System.out.print("Sconto: ");
                    double sconto = sc.nextDouble();

                    System.out.print("Numero ospiti: ");
                    int ospiti = sc.nextInt();

                    System.out.print("Costo totale: ");
                    double costo = sc.nextDouble();
                    sc.nextLine();

                    System.out.print("Nome alloggio: ");
                    String alloggio = sc.nextLine();

                    System.out.print("Email utente: ");
                    String email = sc.nextLine();

                    Operazioni.registraPrenotazione(inizio, fine, sconto, ospiti, costo, alloggio, email);
                }

                case 2 -> {
                    System.out.print("Nome esperienza: ");
                    String exp = sc.nextLine();

                    System.out.print("Email utente: ");
                    String email = sc.nextLine();

                    Operazioni.prenotaEsperienza(exp, email);
                }

                case 3 -> {
                    System.out.print("Nome alloggio: ");
                    String nome = sc.nextLine();

                    System.out.print("Tipo (camera singola/appartamento/villa): ");
                    String tipo = sc.nextLine();

                    System.out.print("Indirizzo: ");
                    String indirizzo = sc.nextLine();

                    System.out.print("Piani: ");
                    int piani = sc.nextInt();

                    System.out.print("Locali: ");
                    int locali = sc.nextInt();

                    System.out.print("Metri quadri: ");
                    int mq = sc.nextInt();

                    System.out.print("Max ospiti: ");
                    int maxOspiti = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Descrizione: ");
                    String descrizione = sc.nextLine();

                    System.out.print("Animali ammessi (true/false): ");
                    boolean animali = Boolean.parseBoolean(sc.nextLine());

                    System.out.print("Bagno privato (true/false): ");
                    boolean bagno = Boolean.parseBoolean(sc.nextLine());

                    System.out.print("Giardino (true/false): ");
                    boolean giardino = Boolean.parseBoolean(sc.nextLine());

                    System.out.print("Genere: ");
                    String genere = sc.nextLine();

                    System.out.print("Link foto: ");
                    String link = sc.nextLine();

                    System.out.print("Email host: ");
                    String host = sc.nextLine();

                    System.out.print("Nome città: ");
                    String citta = sc.nextLine();

                    System.out.print("Costo per notte: ");
                    double costoNotte = sc.nextDouble();
                    sc.nextLine();

                    Operazioni.aggiungiAlloggio(nome, tipo, indirizzo, piani, locali, mq, maxOspiti,
                            descrizione, animali, bagno, giardino, genere, link, host, citta, costoNotte);
                }

                case 4 -> {
                    System.out.print("Nome servizio: ");
                    String servizio = sc.nextLine();

                    System.out.print("Nome alloggio: ");
                    String alloggio = sc.nextLine();

                    Operazioni.aggiungiServizioAlloggio(servizio, alloggio);
                }

                case 5 -> {
                    System.out.print("Nome alloggio: ");
                    String alloggio = sc.nextLine();

                    System.out.print("Nuovo numero locali: ");
                    int locali = sc.nextInt();
                    sc.nextLine();

                    Operazioni.modificaLocali(alloggio, locali);
                }

                case 6 -> Operazioni.stampaPrenotazioni();

                case 7 -> {
                    System.out.print("Nome agenzia: ");
                    String agenzia = sc.nextLine();

                    Operazioni.stampaProfessionistiAgenzia(agenzia);
                }

                case 8 -> Operazioni.stampaUtentiConPrenotazioni();

                case 9 -> Operazioni.stampaAlloggiPerHost();

                case 10 -> {
                    System.out.print("Data inizio (YYYY-MM-DD): ");
                    Date inizio = Date.valueOf(sc.nextLine());

                    System.out.print("Data fine (YYYY-MM-DD): ");
                    Date fine = Date.valueOf(sc.nextLine());

                    System.out.print("Numero minimo ospiti: ");
                    int ospiti = sc.nextInt();
                    sc.nextLine();

                    Operazioni.alloggiDisponibili(inizio, fine, ospiti);
                }

                case 11 -> Operazioni.utentiCon30Giorni();

                case 12 -> Operazioni.ratingMedioHost();

                case 13 -> Operazioni.classificaHost();

                case 14 -> Operazioni.alloggiCon30Ospiti();

                case 15 -> Operazioni.utentiSenzaEsperienze();

                case 0 -> System.out.println("Uscita dal programma.");

                default -> System.out.println("Scelta non valida.");
            }
        }

        sc.close();
    }
}
