DROP SCHEMA IF EXISTS piattaformaturistica;
CREATE SCHEMA piattaformaturistica;
USE piattaformaturistica;


DROP TABLE IF EXISTS Agenzia;
DROP TABLE IF EXISTS Utente;
DROP TABLE IF EXISTS Host;
DROP TABLE IF EXISTS Citta;
DROP TABLE IF EXISTS Lingua;
DROP TABLE IF EXISTS Badge;
DROP TABLE IF EXISTS Servizio;
DROP TABLE IF EXISTS Alloggio;
DROP TABLE IF EXISTS Esperienza;
DROP TABLE IF EXISTS Attrazione;
DROP TABLE IF EXISTS Prenotazione;
DROP TABLE IF EXISTS Recensione;
DROP TABLE IF EXISTS Comunicazione;
DROP TABLE IF EXISTS Offerta;
DROP TABLE IF EXISTS Assegnazione;
DROP TABLE IF EXISTS RecapitoTelefonicoAgenzia;
DROP TABLE IF EXISTS RecapitoTelefonicoUtente;
DROP TABLE IF EXISTS Acquisto;







-----------------------------------------------------
-- CREAZIONE TABELLE
-----------------------------------------------------

CREATE TABLE Agenzia (
    nome VARCHAR(100) PRIMARY KEY,
    sede VARCHAR(255) NOT NULL
);

CREATE TABLE Utente (
    email VARCHAR(255) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cognome VARCHAR(100) NOT NULL,
    nazionalita VARCHAR(100) NOT NULL,
    biografia TEXT
);


CREATE TABLE Host (
    email VARCHAR(255) PRIMARY KEY,
    data_nomina DATE NOT NULL,
    tasso_risposta DECIMAL(5,2),
    nazionalita VARCHAR(100) NOT NULL,
    tipo_host VARCHAR(100) NOT NULL CHECK (tipo_host IN ('host privato','host professionista','superhost')),
    Agenzia_nome VARCHAR(100),
    FOREIGN KEY (Agenzia_nome) REFERENCES Agenzia(nome)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Citta (
    nome VARCHAR(100) PRIMARY KEY ,
    regione VARCHAR(100) NOT NULL,
    nazione VARCHAR(100) NOT NULL
);


CREATE TABLE Lingua (
    nome VARCHAR(100) PRIMARY KEY
);


CREATE TABLE Badge (
    ID INT AUTO_INCREMENT PRIMARY KEY
);

CREATE TABLE Servizio (
    nome VARCHAR(100) NOT NULL PRIMARY KEY,
    tipo VARCHAR(100) NOT NULL CHECK (tipo IN ('base','comfort','pulizia','cucina','accessibilità','famiglia','animali','business','benessere','mobilità'))
);



CREATE TABLE Alloggio (
    nome VARCHAR(100) PRIMARY KEY,
    tipo VARCHAR(100) NOT NULL CHECK (tipo IN ('camera singola','appartamento','villa')),
    indirizzo VARCHAR(255) NOT NULL,
    piani INT,
    locali INT,
	mq INT NOT NULL,
	max_ospiti INT NOT NULL,
    descrizione TEXT NOT NULL,
	ammissione_animali BOOLEAN NOT NULL,
	bagno_privato BOOLEAN,
	giardino BOOLEAN,
    genere VARCHAR(100),
    link_foto TEXT NOT NULL,
    Host_email VARCHAR(255) NOT NULL,
	Citta_nome VARCHAR(100) NOT NULL,
	costo_per_notte DECIMAL(5,2),
    FOREIGN KEY (Host_email) REFERENCES Host(email)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (Citta_nome) REFERENCES Citta(nome)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Esperienza (
    nome VARCHAR(100) PRIMARY KEY,
    data DATE NOT NULL,
    max_partecipanti INT NOT NULL,
    descrizione TEXT NOT NULL,
    prezzo_unitario DECIMAL(10,2) NOT NULL,
    Agenzia_nome VARCHAR(100) NOT NULL,
    FOREIGN KEY (Agenzia_nome) REFERENCES Agenzia(nome)
    ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Attrazione (
    nome VARCHAR(100) PRIMARY KEY,
    Citta_nome VARCHAR(100) NOT NULL,
    FOREIGN KEY (Citta_nome) REFERENCES Citta(nome)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE Prenotazione (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    data_inizio DATE NOT NULL,
    data_fine DATE NOT NULL,
    sconto DECIMAL(5,2),
    numero_ospiti INT NOT NULL,
    costo_totale DECIMAL(10,2) NOT NULL,
    Alloggio_nome VARCHAR(100) NOT NULL,
    Utente_email VARCHAR(255) NOT NULL,
    FOREIGN KEY (Alloggio_nome) REFERENCES Alloggio(nome)
   ON DELETE CASCADE ON UPDATE CASCADE ,
    FOREIGN KEY (Utente_email) REFERENCES Utente(email)
    ON DELETE CASCADE ON UPDATE CASCADE
);



CREATE TABLE Recensione (
    data DATE NOT NULL,
    Prenotazione_ID INT NOT NULL,
    testo_descrittivo TEXT NOT NULL,
    pulizia INT NOT NULL CHECK (pulizia BETWEEN 1 AND 5),
    qualita_alloggio INT NOT NULL CHECK (qualita_alloggio BETWEEN 1 AND 5),
    precisione_annuncio INT NOT NULL CHECK (precisione_annuncio BETWEEN 1 AND 5),
    disponibilita INT NOT NULL CHECK (disponibilita BETWEEN 1 AND 5),
    PRIMARY KEY (data, Prenotazione_ID),
    FOREIGN KEY (Prenotazione_ID) REFERENCES Prenotazione(ID)
    ON DELETE CASCADE ON UPDATE CASCADE
);  

CREATE TABLE Comunicazione (
    Lingua_nome VARCHAR(100) NOT NULL,
    Host_email VARCHAR(255) NOT NULL,
    PRIMARY KEY (Lingua_nome, Host_email),
    FOREIGN KEY (Lingua_nome) REFERENCES Lingua(nome)
    ON DELETE CASCADE ON UPDATE CASCADE  ,
    FOREIGN KEY (Host_email) REFERENCES Host(email)
    ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Offerta (
    Servizio_nome VARCHAR(100) NOT NULL,
    Alloggio_nome VARCHAR(100) NOT NULL,
    PRIMARY KEY (Servizio_nome, Alloggio_nome)
);





CREATE TABLE Assegnazione (
    Host_email VARCHAR(255) NOT NULL,
    Badge_ID INT NOT NULL,
    PRIMARY KEY (Host_email, Badge_ID),
    FOREIGN KEY (Host_email) REFERENCES Host(email)
   ON DELETE CASCADE ON UPDATE CASCADE ,
    FOREIGN KEY (Badge_ID) REFERENCES Badge(ID)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE RecapitoTelefonicoAgenzia (
    numero VARCHAR(50) PRIMARY KEY,
    Agenzia_nome VARCHAR(100) NOT NULL,
    FOREIGN KEY (Agenzia_nome) REFERENCES Agenzia(nome)
    ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE RecapitoTelefonicoUtente (
    numero VARCHAR(50) PRIMARY KEY,
    Utente_email VARCHAR(255) NOT NULL,
    FOREIGN KEY (Utente_email) REFERENCES Utente(email)
    ON DELETE CASCADE ON UPDATE CASCADE
);



CREATE TABLE Acquisto (
    Esperienza_nome VARCHAR(100) NOT NULL,
    Utente_email VARCHAR(255) NOT NULL,
    PRIMARY KEY (Esperienza_nome , Utente_email),
    FOREIGN KEY (Esperienza_nome)
        REFERENCES Esperienza (nome)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (Utente_email)
        REFERENCES Utente (email)
        ON DELETE CASCADE ON UPDATE CASCADE
);
